import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useGameContext } from "@/context/GameContext";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { User, ArrowLeft, Grid, Video, Bookmark, Tag, ImageIcon } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const UserProfile = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const { users, currentUser, followUser, unfollowUser } = useGameContext();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [isFollowing, setIsFollowing] = useState(false);
  
  useEffect(() => {
    if (userId) {
      const foundUser = users.find(u => u.id === userId);
      if (foundUser) {
        setUser(foundUser);
        setIsFollowing(currentUser?.following.includes(foundUser.id) || false);
      }
    }
    setLoading(false);
  }, [userId, users, currentUser]);
  
  const handleFollow = () => {
    if (user && currentUser) {
      if (isFollowing) {
        unfollowUser(user.id);
        setIsFollowing(false);
      } else {
        followUser(user.id);
        setIsFollowing(true);
      }
    }
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="ios-spinner"></div>
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold">User not found</h2>
        <Button onClick={() => navigate("/")} className="mt-4">
          Back to Home
        </Button>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-background pb-16">
      <div className="bg-white dark:bg-card shadow-sm border-b border-gray-200 dark:border-gray-800 fixed top-0 left-0 right-0 z-10">
        <div className="container mx-auto px-4 py-3 max-w-md flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate("/")}
            className="rounded-full"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold">{user.username}</h1>
          <div className="w-8"></div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 max-w-md pt-16">
        <div className="pt-4 pb-4">
          <div className="flex items-center gap-6">
            <div className="story-ring">
              <Avatar className="h-20 w-20">
                {user.profileImage ? (
                  <img src={user.profileImage} alt={user.username} className="h-full w-full object-cover" />
                ) : (
                  <div className="bg-gradient-to-br from-red-500 via-purple-500 to-blue-500 flex items-center justify-center h-full w-full text-white text-xl font-bold">
                    {user.username.charAt(0).toUpperCase()}
                  </div>
                )}
              </Avatar>
            </div>
            
            <div className="flex-1 flex justify-between text-center">
              <div>
                <p className="font-bold">{user.posts.length}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Posts</p>
              </div>
              <div>
                <p className="font-bold">{user.followers}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Followers</p>
              </div>
              <div>
                <p className="font-bold">{user.followingCount}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">Following</p>
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <h2 className="font-semibold flex items-center">
              {user.username}
              {user.isVerified && (
                <span className="ml-1 text-blue-500">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                    <path fillRule="evenodd" d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z" clipRule="evenodd" />
                  </svg>
                </span>
              )}
            </h2>
            <p className="text-sm mt-1">{user.bio}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Level {user.level} • {user.stars} Coins</p>
          </div>
          
          <div className="mt-4 flex gap-2">
            {currentUser && currentUser.id !== user.id ? (
              <>
                <Button 
                  onClick={handleFollow}
                  className={`flex-1 ${isFollowing ? 'bg-gray-200 dark:bg-gray-800 text-foreground' : 'bg-blue-500 text-white'}`}
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1 border-gray-300 dark:border-gray-700"
                  onClick={() => navigate(`/chat/${user.id}`)}
                >
                  Message
                </Button>
              </>
            ) : (
              <Button 
                variant="outline" 
                className="w-full border-gray-300 dark:border-gray-700"
                onClick={() => navigate('/profile/edit')}
              >
                Edit Profile
              </Button>
            )}
          </div>
          
          <div className="mt-6">
            <div className="highlight-container">
              {['Travel', 'Food', 'Nature', 'Friends'].map((highlight, index) => (
                <div key={index} className="highlight-item">
                  <div className="story-ring">
                    <div className="h-16 w-16 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                      <span className="text-gray-400 dark:text-gray-500 text-xs">{highlight.charAt(0)}</span>
                    </div>
                  </div>
                  <span className="text-xs mt-1">{highlight}</span>
                </div>
              ))}
              {currentUser && currentUser.id === user.id && (
                <div className="highlight-item">
                  <div className="h-16 w-16 rounded-full border-2 border-dashed border-gray-300 dark:border-gray-700 flex items-center justify-center">
                    <span className="text-2xl text-gray-400">+</span>
                  </div>
                  <span className="text-xs mt-1">New</span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid w-full grid-cols-4 rounded-none border-b border-gray-200 dark:border-gray-800 bg-transparent">
            <TabsTrigger value="posts" className="data-[state=active]:border-b-2 data-[state=active]:border-black dark:data-[state=active]:border-white rounded-none">
              <Grid className="h-5 w-5" />
            </TabsTrigger>
            <TabsTrigger value="reels" className="data-[state=active]:border-b-2 data-[state=active]:border-black dark:data-[state=active]:border-white rounded-none">
              <Video className="h-5 w-5" />
            </TabsTrigger>
            <TabsTrigger value="saved" className="data-[state=active]:border-b-2 data-[state=active]:border-black dark:data-[state=active]:border-white rounded-none">
              <Bookmark className="h-5 w-5" />
            </TabsTrigger>
            <TabsTrigger value="tagged" className="data-[state=active]:border-b-2 data-[state=active]:border-black dark:data-[state=active]:border-white rounded-none">
              <Tag className="h-5 w-5" />
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts" className="mt-2">
            {user.posts.length > 0 ? (
              <div className="grid grid-cols-3 gap-1">
                {user.posts.map((post: any) => (
                  <div key={post.id} className="aspect-square bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                    {post.type === "photo" ? (
                      <ImageIcon className="h-5 w-5 text-gray-400" />
                    ) : (
                      <Video className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center">
                <User className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                <h3 className="font-semibold">No Posts Yet</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {currentUser && currentUser.id === user.id ? 'Share your first post' : 'This user has no posts yet'}
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="reels" className="mt-2">
            <div className="py-8 text-center">
              <Video className="h-12 w-12 mx-auto mb-2 text-gray-300" />
              <h3 className="font-semibold">No Reels Yet</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Reels will appear here</p>
            </div>
          </TabsContent>
          
          <TabsContent value="saved" className="mt-2">
            <div className="py-8 text-center">
              <Bookmark className="h-12 w-12 mx-auto mb-2 text-gray-300" />
              <h3 className="font-semibold">No Saved Items</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {currentUser && currentUser.id === user.id ? 'Save photos and videos to view them later' : 'This section is private'}
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="tagged" className="mt-2">
            <div className="py-8 text-center">
              <Tag className="h-12 w-12 mx-auto mb-2 text-gray-300" />
              <h3 className="font-semibold">No Tagged Posts</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">Posts that tag this user will appear here</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UserProfile;
