import { useState, useEffect } from "react";
import ProfilePage from "@/components/sence/ProfilePage";
import Feed from "@/components/sence/Feed";
import CreateContent from "@/components/sence/CreateContent";
import Dashboard from "@/components/sence/Dashboard";
import Achievements from "@/components/sence/Achievements";
import NavBar from "@/components/sence/NavBar";
import Wallet from "@/components/sence/Wallet";
import Messages from "@/components/sence/Messages";
import Reels from "@/components/sence/Reels";
import Login from "@/components/sence/Login";
import { GameProvider, useGameContext } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { Plus, ChevronUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Search } from "@/components/sence/Search";

const AppContent = () => {
  const { isAuthenticated, collectDailyBonus, currentUser } = useGameContext();
  const [activeTab, setActiveTab] = useState("feed");
  const [isLoading, setIsLoading] = useState(true);
  const [showFloatingButton, setShowFloatingButton] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 200) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);
  
  useEffect(() => {
    if (currentUser?.dailyBonus) {
      const timer = setTimeout(() => {
        showBonusAvailable();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [currentUser]);

  const showBonusAvailable = () => {
    setShowFloatingButton(true);
    setTimeout(() => {
      setShowFloatingButton(false);
    }, 5000);
  };

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const handleCollectBonus = () => {
    collectDailyBonus();
    setShowFloatingButton(false);
  };

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <>
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-pulse text-gradient text-3xl font-bold">
            Sence Coin
          </div>
        </div>
      ) : (
        <>
          <header className="mb-5">
            <div className="flex justify-between items-center px-1">
              <h1 className="text-3xl font-bold text-gradient">
                Sence Coin
              </h1>
              <div className="flex space-x-3">
                <Search />
                <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-50 text-gray-700 relative">
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-bell">
                    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/>
                    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                  </svg>
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">3</span>
                </button>
              </div>
            </div>
            <p className="text-center text-gray-500 text-sm mt-1">
              Connect with creators and earn rewards!
            </p>
          </header>

          <main className="animate-fade-in">
            {activeTab === "dashboard" && <Dashboard />}
            {activeTab === "profile" && <ProfilePage />}
            {activeTab === "create" && <CreateContent />}
            {activeTab === "feed" && <Feed />}
            {activeTab === "reels" && <Reels />}
            {activeTab === "achievements" && <Achievements />}
            {activeTab === "wallet" && <Wallet />}
            {activeTab === "messages" && <Messages />}
          </main>

          <NavBar activeTab={activeTab} setActiveTab={setActiveTab} />

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  onClick={() => navigate('/create')}
                  size="icon"
                  className="fixed z-20 bottom-20 right-4 h-12 w-12 rounded-full shadow-lg bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                >
                  <Plus className="h-5 w-5" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Create new content</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {showFloatingButton && (
            <Button
              onClick={handleCollectBonus}
              variant="outline"
              className="fixed z-20 bottom-20 left-4 px-3 py-2 rounded-full shadow-lg bg-yellow-400 hover:bg-yellow-500 text-black border-yellow-500 animate-bounce"
            >
              <span role="img" aria-label="star" className="mr-1">⭐</span>
              Collect Daily Bonus
            </Button>
          )}

          {showScrollTop && (
            <Button
              onClick={handleScrollToTop}
              size="icon"
              variant="outline"
              className="fixed z-20 bottom-20 left-4 h-10 w-10 rounded-full shadow-lg bg-white opacity-70 hover:opacity-100"
            >
              <ChevronUp className="h-5 w-5" />
            </Button>
          )}
        </>
      )}
    </>
  );
};

const Index = () => {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <GameProvider>
        <div className="container mx-auto px-4 py-5 max-w-md">
          <AppContent />
        </div>
      </GameProvider>
    </div>
  );
};

export default Index;
