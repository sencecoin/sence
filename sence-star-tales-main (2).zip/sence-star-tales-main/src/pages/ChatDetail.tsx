import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useGameContext } from "@/context/GameContext";
import {
  ArrowLeft, Phone, Video, Mic, Camera, Image, Send,
  MoreVertical, Paperclip, Smile, Info, Bookmark, UserCheck,
  VolumeX, Bell, Lock, Shield, Flag, ThumbsDown, Heart, MessageCircle,
  User
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { Avatar } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Drawer, DrawerContent, DrawerTrigger } from "@/components/ui/drawer";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const QuickReplies = [
  "Hey! How are you?",
  "Sure, sounds good!",
  "What are you up to?",
  "I'll get back to you soon",
  "Thanks!",
  "Can we talk later?",
  "😊👍",
  "That's awesome!"
];

const ChatDetail = () => {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { currentUser, users, sendMessage, getMessages, initiateCall, endCall } = useGameContext();
  const { toast } = useToast();
  
  const [messageText, setMessageText] = useState("");
  const [messages, setMessages] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isShowingMediaOptions, setIsShowingMediaOptions] = useState(false);
  const [activeCall, setActiveCall] = useState<{id: string, type: "voice" | "video"} | null>(null);
  const [replyingTo, setReplyingTo] = useState<any>(null);
  const [isUserInfoOpen, setIsUserInfoOpen] = useState(false);
  const [showQuickReplies, setShowQuickReplies] = useState(false);
  const [mediaGallery, setMediaGallery] = useState<{type: string, url: string}[]>([
    { type: 'image', url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158' },
    { type: 'image', url: 'https://images.unsplash.com/photo-1523712999610-f77fbcfc3843' },
    { type: 'video', url: 'https://example.com/video.mp4' }
  ]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    if (!currentUser) {
      navigate("/");
      return;
    }
    
    if (!userId) {
      navigate("/");
      return;
    }
    
    // Find selected user
    const user = users.find(u => u.id === userId);
    if (user) {
      setSelectedUser(user);
    } else {
      navigate("/");
      return;
    }
    
    // Get messages
    const chatMessages = getMessages(userId);
    setMessages(chatMessages);
    
    // Set up message polling
    const intervalId = setInterval(() => {
      const updatedMessages = getMessages(userId);
      if (updatedMessages.length !== messages.length) {
        setMessages(updatedMessages);
      }
    }, 2000);
    
    // Simulate typing indicators
    if (chatMessages.length > 0 && Math.random() > 0.7) {
      setTimeout(() => {
        const fakeReply = {
          id: `temp-${Date.now()}`,
          conversationId: userId,
          text: Math.random() > 0.5 
            ? "Thanks for your message! How can I help you today?"
            : "I was just thinking about you. How's everything going?",
          timestamp: new Date(),
          isOwn: false,
          read: false,
        };
        
        setMessages(prev => [...prev, fakeReply]);
      }, 3000 + Math.random() * 5000);
    }
    
    return () => clearInterval(intervalId);
  }, [currentUser, userId, users, navigate, getMessages]);
  
  // Scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const handleSendMessage = () => {
    if (!messageText.trim() || !userId || !currentUser) return;
    
    const replyContext = replyingTo ? { replyTo: replyingTo.id, replyText: replyingTo.text } : null;
    
    sendMessage(userId, messageText);
    
    // Update local messages for immediate feedback
    const newMessages = getMessages(userId);
    setMessages(newMessages);
    
    // Clear reply state
    setReplyingTo(null);
    setMessageText("");
    
    // Focus back on the input
    inputRef.current?.focus();
  };
  
  const handleStartCall = (type: "voice" | "video") => {
    if (!userId || !currentUser) return;
    
    try {
      const call = initiateCall(userId, type);
      
      setActiveCall({
        id: call.id,
        type
      });
      
      toast({
        title: `${type === 'voice' ? 'Voice' : 'Video'} Call Started`,
        description: `Call with ${selectedUser?.username}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start call",
        variant: "destructive"
      });
    }
  };
  
  const handleEndCall = () => {
    if (!activeCall) return;
    
    endCall(activeCall.id);
    
    toast({
      title: "Call Ended",
      description: `Call with ${selectedUser?.username} has ended`,
    });
    
    setActiveCall(null);
  };
  
  const handleReply = (message: any) => {
    setReplyingTo(message);
    inputRef.current?.focus();
  };
  
  const handleLikeMessage = (messageId: string) => {
    // In a real app, you would update the message in the database
    toast({
      title: "Message liked",
      description: "The message has been liked",
    });
  };
  
  const handleQuickReply = (text: string) => {
    setMessageText(text);
    setShowQuickReplies(false);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };
  
  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  const formatDate = (date: Date) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const messageDate = new Date(date);
    
    if (messageDate.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (messageDate.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return messageDate.toLocaleDateString([], { 
        weekday: 'short', 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };
  
  if (!selectedUser || !currentUser) {
    return null;
  }
  
  // Group messages by date
  const groupedMessages: { [key: string]: any[] } = {};
  messages.forEach(message => {
    const dateKey = formatDate(message.timestamp);
    if (!groupedMessages[dateKey]) {
      groupedMessages[dateKey] = [];
    }
    groupedMessages[dateKey].push(message);
  });
  
  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Active Call UI */}
      {activeCall && (
        <div className="fixed inset-0 z-50 bg-gradient-to-b from-black to-gray-900 flex flex-col items-center justify-center">
          <div className="text-white text-center">
            <div className="mb-8">
              <Avatar className="h-32 w-32 mx-auto mb-4">
                {selectedUser.profileImage ? (
                  <img 
                    src={selectedUser.profileImage} 
                    alt={selectedUser.username}
                    className="h-full w-full object-cover rounded-full" 
                  />
                ) : (
                  <div className="bg-blue-600 text-white flex items-center justify-center h-full w-full rounded-full text-xl">
                    {selectedUser.username.charAt(0).toUpperCase()}
                  </div>
                )}
              </Avatar>
              <h2 className="text-2xl font-medium">{selectedUser.username}</h2>
              <p className="text-gray-300 mt-2">
                {activeCall.type === 'voice' ? 'Voice call' : 'Video call'} • {formatTime(new Date())}
              </p>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mt-8">
              <Button 
                variant="ghost" 
                size="icon" 
                className="w-16 h-16 rounded-full bg-gray-800 hover:bg-gray-700 border-none mx-auto"
              >
                <Mic className="h-6 w-6 text-white" />
              </Button>
              
              <Button 
                variant="destructive" 
                size="icon" 
                className="w-16 h-16 rounded-full mx-auto"
                onClick={handleEndCall}
              >
                <Phone className="h-6 w-6 text-white rotate-135" />
              </Button>
              
              <Button 
                variant="ghost" 
                size="icon" 
                className="w-16 h-16 rounded-full bg-gray-800 hover:bg-gray-700 border-none mx-auto"
              >
                <Video className="h-6 w-6 text-white" />
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 p-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon"
            className="mr-2"
            onClick={() => navigate("/")}
          >
            <ArrowLeft size={22} />
          </Button>
          
          <Avatar className="h-10 w-10 mr-3" onClick={() => setIsUserInfoOpen(true)}>
            {selectedUser.profileImage ? (
              <img 
                src={selectedUser.profileImage} 
                alt={selectedUser.username}
                className="h-full w-full object-cover rounded-full" 
              />
            ) : (
              <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center h-full w-full rounded-full">
                {selectedUser.username.charAt(0).toUpperCase()}
              </div>
            )}
          </Avatar>
          
          <div onClick={() => setIsUserInfoOpen(true)} className="cursor-pointer">
            <div className="flex items-center">
              <p className="font-medium text-gray-800">{selectedUser.username}</p>
              {selectedUser.isVerified && (
                <Badge className="ml-2 bg-blue-500 h-4 px-1 text-[10px]">Verified</Badge>
              )}
            </div>
            <p className="text-xs text-green-500 flex items-center">
              <span className="h-2 w-2 rounded-full bg-green-500 mr-1 animate-pulse"></span> 
              Online
            </p>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button 
            variant="ghost" 
            size="icon"
            className="text-blue-500"
            onClick={() => handleStartCall("voice")}
          >
            <Phone size={20} />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon"
            className="text-blue-500"
            onClick={() => handleStartCall("video")}
          >
            <Video size={20} />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-gray-500">
                <MoreVertical size={20} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setIsUserInfoOpen(true)}>
                <Info className="mr-2 h-4 w-4" /> View profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Bookmark className="mr-2 h-4 w-4" /> Save messages
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Bell className="mr-2 h-4 w-4" /> Mute notifications
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-500">
                <Flag className="mr-2 h-4 w-4" /> Report
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-500">
                <ThumbsDown className="mr-2 h-4 w-4" /> Block user
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-gray-50">
        {/* User info sheet */}
        {isUserInfoOpen && (
          <Sheet open={isUserInfoOpen} onOpenChange={setIsUserInfoOpen}>
            <SheetContent side="right" className="w-full sm:w-96">
              <div className="h-full flex flex-col">
                <div className="text-center py-6">
                  <Avatar className="h-24 w-24 mx-auto mb-4 ring-4 ring-offset-2 ring-blue-100">
                    {selectedUser.profileImage ? (
                      <img 
                        src={selectedUser.profileImage} 
                        alt={selectedUser.username}
                        className="h-full w-full object-cover rounded-full" 
                      />
                    ) : (
                      <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center h-full w-full rounded-full text-xl">
                        {selectedUser.username.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </Avatar>
                  <h2 className="text-xl font-semibold">{selectedUser.username}</h2>
                  {selectedUser.isVerified && (
                    <Badge className="mt-1 bg-blue-500">Verified Account</Badge>
                  )}
                  <p className="text-gray-500 mt-2">{selectedUser.bio}</p>
                </div>
                
                <Tabs defaultValue="gallery" className="flex-1">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="gallery">Gallery</TabsTrigger>
                    <TabsTrigger value="files">Files</TabsTrigger>
                    <TabsTrigger value="links">Links</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="gallery" className="p-2">
                    <div className="grid grid-cols-3 gap-1">
                      {mediaGallery.map((media, index) => (
                        <div key={index} className="aspect-square bg-gray-200 rounded-md overflow-hidden">
                          {media.type === 'image' ? (
                            <img 
                              src={media.url} 
                              alt="Shared media" 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                              <Video className="w-8 h-8 text-white" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="files" className="p-2">
                    <div className="text-center py-8 text-gray-500">
                      <p>No files shared yet</p>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="links" className="p-2">
                    <div className="text-center py-8 text-gray-500">
                      <p>No links shared yet</p>
                    </div>
                  </TabsContent>
                </Tabs>
                
                <div className="border-t border-gray-200 py-4">
                  <h3 className="text-sm text-gray-500 mb-3">Privacy & Support</h3>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <Lock className="mr-2 h-4 w-4 text-gray-500" />
                      <span>End-to-end encrypted</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Shield className="mr-2 h-4 w-4 text-gray-500" />
                      <span>Messages disappear: Off</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <Button 
                      variant="outline" 
                      className="w-full border-red-200 text-red-500 hover:bg-red-50"
                    >
                      <Flag className="mr-2 h-4 w-4" />
                      Report account
                    </Button>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        )}
        
        {Object.keys(groupedMessages).length > 0 ? (
          <>
            {Object.entries(groupedMessages).map(([dateKey, dateMessages]) => (
              <div key={dateKey}>
                <div className="flex justify-center mb-4">
                  <div className="bg-gray-200 text-gray-600 px-3 py-1 rounded-full text-xs">
                    {dateKey}
                  </div>
                </div>
                
                <div className="space-y-4">
                  {dateMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.isOwn ? "justify-end" : "justify-start"}`}
                    >
                      {!message.isOwn && (
                        <Avatar className="h-8 w-8 mr-2 self-end mb-1">
                          {selectedUser.profileImage ? (
                            <img 
                              src={selectedUser.profileImage} 
                              alt={selectedUser.username}
                              className="h-full w-full object-cover rounded-full" 
                            />
                          ) : (
                            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center h-full w-full rounded-full text-xs">
                              {selectedUser.username.charAt(0).toUpperCase()}
                            </div>
                          )}
                        </Avatar>
                      )}
                      
                      <div className="group max-w-[75%]">
                        {message.replyTo && (
                          <div 
                            className={`text-xs ${
                              message.isOwn ? "text-blue-200 text-right mr-3" : "text-gray-500 ml-3"
                            } mb-1`}
                          >
                            Replying to "{message.replyText.substring(0, 30)}..."
                          </div>
                        )}
                        
                        <div
                          className={`p-3 rounded-2xl ${
                            message.isOwn
                              ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-br-none"
                              : "bg-white text-gray-800 rounded-bl-none border border-gray-100 shadow-sm"
                          } relative`}
                        >
                          <p>{message.text}</p>
                          <div className={`text-xs mt-1 flex justify-end ${message.isOwn ? "text-blue-100" : "text-gray-500"}`}>
                            {formatTime(message.timestamp)}
                            {message.isOwn && (
                              <span className="ml-1">{message.read ? "✓✓" : "✓"}</span>
                            )}
                          </div>
                          
                          <div className={`absolute ${message.isOwn ? "-left-10" : "-right-10"} top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity`}>
                            <div className="flex flex-col space-y-2">
                              <Button 
                                variant="outline" 
                                size="icon" 
                                className="h-7 w-7 rounded-full bg-white shadow-sm"
                                onClick={() => handleReply(message)}
                              >
                                <MessageCircle className="h-3 w-3 text-gray-600" />
                              </Button>
                              
                              {!message.isOwn && (
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  className="h-7 w-7 rounded-full bg-white shadow-sm"
                                  onClick={() => handleLikeMessage(message.id)}
                                >
                                  <Heart className="h-3 w-3 text-gray-600" />
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </>
        ) : (
          <div className="text-center py-10">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <User className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-gray-500">No messages yet</h3>
            <p className="text-gray-400 text-sm mt-1">Start a conversation with {selectedUser.username}</p>
            
            <div className="flex justify-center mt-6 space-x-2">
              {QuickReplies.slice(0, 3).map((reply, index) => (
                <Button 
                  key={index} 
                  variant="outline"
                  size="sm" 
                  className="bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                  onClick={() => handleQuickReply(reply)}
                >
                  {reply}
                </Button>
              ))}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Reply To Interface */}
      {replyingTo && (
        <div className="bg-white border-t border-gray-200 p-2 animate-fade-in">
          <div className="flex items-center justify-between bg-gray-50 p-2 rounded-lg">
            <div className="flex-1">
              <p className="text-xs text-gray-500">Replying to</p>
              <p className="text-sm text-gray-700 truncate">{replyingTo.text}</p>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setReplyingTo(null)} 
              className="h-8 w-8 p-0"
            >
              <span className="text-2xl text-gray-400">×</span>
            </Button>
          </div>
        </div>
      )}
      
      {/* Chat Input */}
      <div className="bg-white border-t border-gray-200 p-3 sticky bottom-0 z-10">
        <div className="flex items-center">
          <Drawer>
            <DrawerTrigger asChild>
              <Button variant="ghost" size="icon" className="text-blue-500">
                <Smile size={22} />
              </Button>
            </DrawerTrigger>
            <DrawerContent className="h-[40vh]">
              <div className="p-4">
                <h3 className="font-medium text-lg mb-3">Emojis</h3>
                <div className="grid grid-cols-8 gap-2">
                  {["😀", "😂", "😍", "🥰", "😎", "🤔", "👍", "👏", "🎉", "❤️", "🔥", "👋", "😊", "🙏", "🤩", "😘"].map((emoji) => (
                    <button
                      key={emoji}
                      className="text-2xl p-2 hover:bg-gray-100 rounded-full"
                      onClick={() => {
                        setMessageText(prev => prev + emoji);
                      }}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
            </DrawerContent>
          </Drawer>
          
          <Popover open={showQuickReplies} onOpenChange={setShowQuickReplies}>
            <PopoverTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon"
                className="text-blue-500"
                onClick={() => setIsShowingMediaOptions(!isShowingMediaOptions)}
              >
                <Paperclip size={22} />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-72 p-2">
              <h3 className="font-medium mb-2">Quick Replies</h3>
              <div className="grid grid-cols-2 gap-2">
                {QuickReplies.map((reply, index) => (
                  <Button 
                    key={index} 
                    variant="outline"
                    size="sm" 
                    className="h-auto py-2 justify-start text-left text-sm font-normal"
                    onClick={() => handleQuickReply(reply)}
                  >
                    {reply}
                  </Button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          
          <Input
            placeholder="Message"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleSendMessage();
              }
            }}
            className="mx-2 rounded-full bg-gray-100 border-none"
            ref={inputRef}
          />
          
          <Button 
            variant={messageText.trim() ? "default" : "ghost"}
            size="icon" 
            className={messageText.trim() ? "bg-gradient-to-r from-blue-500 to-blue-600" : "text-gray-400"}
            onClick={handleSendMessage}
            disabled={!messageText.trim()}
          >
            <Send size={22} />
          </Button>
        </div>
        
        {isShowingMediaOptions && (
          <div className="grid grid-cols-4 gap-2 mt-3 p-2 bg-gray-50 rounded-lg animate-fade-in">
            <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mb-1">
                <Camera size={20} className="text-white" />
              </div>
              <span className="text-xs">Camera</span>
            </button>
            
            <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg">
              <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-1">
                <Image size={20} className="text-white" />
              </div>
              <span className="text-xs">Gallery</span>
            </button>
            
            <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg">
              <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mb-1">
                <Mic size={20} className="text-white" />
              </div>
              <span className="text-xs">Audio</span>
            </button>
            
            <button className="flex flex-col items-center p-2 hover:bg-gray-100 rounded-lg">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mb-1">
                <Video size={20} className="text-white" />
              </div>
              <span className="text-xs">Video</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatDetail;
