
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useGameContext } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { ArrowLeft, User, Camera, X, Plus, Award, Lock, Bell, Moon, ShieldAlert, HelpCircle, LogOut } from "lucide-react";

// Highlight Edit Component
const HighlightEdit = ({ title = "", image = null, isAdd = false, onAdd = () => {} }) => {
  return (
    <div className="highlight-item mr-4 w-20">
      {isAdd ? (
        <button 
          onClick={onAdd}
          className="rounded-full border-2 border-dashed border-gray-300 h-16 w-16 flex items-center justify-center mb-1 mx-auto"
        >
          <Plus className="h-6 w-6 text-gray-400" />
        </button>
      ) : (
        <div className="rounded-full border-2 border-gray-200 h-16 w-16 overflow-hidden mb-1 mx-auto relative group">
          {image ? (
            <img src={image} alt={title} className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-gray-100 flex items-center justify-center">
              <Award className="h-6 w-6 text-gray-400" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
            <X className="h-5 w-5 text-white" />
          </div>
        </div>
      )}
      <span className="text-xs truncate w-full text-center">
        {isAdd ? "New" : title}
      </span>
    </div>
  );
};

const ProfileEdit = () => {
  const navigate = useNavigate();
  const { currentUser, updateUserProfile } = useGameContext();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const highlightImageRef = useRef<HTMLInputElement>(null);
  
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [highlights, setHighlights] = useState([
    { id: "1", title: "Travel", image: null },
    { id: "2", title: "Food", image: null },
  ]);
  const [highlightTitle, setHighlightTitle] = useState("");
  const [showAddHighlight, setShowAddHighlight] = useState(false);
  
  // Initialize form data after component mounts and currentUser is available
  useEffect(() => {
    if (currentUser) {
      setUsername(currentUser.username || "");
      setBio(currentUser.bio || "");
      setProfileImage(currentUser.profileImage || null);
    }
  }, [currentUser]);

  // Redirect if not logged in
  useEffect(() => {
    if (!currentUser) {
      navigate("/");
    }
  }, [currentUser, navigate]);

  const handleSave = () => {
    if (username.trim() === "") {
      toast({
        title: "Error",
        description: "Username cannot be empty",
        variant: "destructive",
      });
      return;
    }
    
    if (currentUser) {
      updateUserProfile({
        username,
        bio,
        profileImage
      });
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully",
      });
      
      navigate("/");
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };
  
  const removeProfileImage = () => {
    setProfileImage(null);
  };

  const addHighlight = () => {
    setShowAddHighlight(true);
  };

  const saveHighlight = () => {
    if (highlightTitle.trim()) {
      setHighlights([
        ...highlights,
        {
          id: Date.now().toString(),
          title: highlightTitle,
          image: null
        }
      ]);
      setHighlightTitle("");
      setShowAddHighlight(false);
    }
  };

  if (!currentUser) return null;

  return (
    <div className="pb-20 pt-3 px-4 max-w-md mx-auto">
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" onClick={() => navigate(-1)} className="p-2">
          <ArrowLeft size={24} />
        </Button>
        <h1 className="text-xl font-semibold">Edit Profile</h1>
        <Button variant="ghost" onClick={handleSave} className="text-primary font-semibold">
          Save
        </Button>
      </div>

      <Card className="phantom-card mb-5">
        <CardContent className="p-4">
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              {profileImage ? (
                <div className="relative">
                  <div className="h-24 w-24 rounded-full instagram-gradient p-0.5 flex items-center justify-center">
                    <img 
                      src={profileImage} 
                      alt="Profile" 
                      className="h-full w-full rounded-full object-cover bg-white p-0.5"
                    />
                  </div>
                  <button 
                    className="absolute -top-2 -right-2 bg-red-500 rounded-full p-1 text-white"
                    onClick={removeProfileImage}
                  >
                    <X size={14} />
                  </button>
                </div>
              ) : (
                <div className="h-24 w-24 instagram-gradient rounded-full p-0.5 flex items-center justify-center">
                  <div className="h-full w-full bg-white rounded-full flex items-center justify-center">
                    <User className="h-12 w-12 text-gray-400" />
                  </div>
                </div>
              )}
              
              <Button 
                variant="outline" 
                className="absolute bottom-0 right-0 rounded-full h-8 w-8 p-0 bg-white"
                onClick={triggerFileInput}
              >
                <Camera size={16} />
              </Button>
              
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept="image/*" 
                onChange={handleImageUpload} 
              />
            </div>
            
            <h2 className="text-lg font-medium">Change Profile Photo</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <Input 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Username"
                className="w-full rounded-xl"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
              <Textarea 
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Write a bio..."
                className="w-full min-h-[100px] rounded-xl"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="phantom-card mb-5">
        <CardContent className="p-4">
          <h3 className="font-medium text-gray-800 mb-3">Story Highlights</h3>
          <p className="text-sm text-gray-500 mb-4">Keep your favorite stories on your profile</p>
          
          <ScrollArea className="w-full">
            <div className="flex pb-2">
              <HighlightEdit isAdd={true} onAdd={addHighlight} />
              {highlights.map(highlight => (
                <HighlightEdit 
                  key={highlight.id} 
                  title={highlight.title} 
                  image={highlight.image}
                />
              ))}
            </div>
          </ScrollArea>
          
          {showAddHighlight && (
            <div className="mt-4 border-t pt-4">
              <h4 className="font-medium text-sm mb-2">New Highlight</h4>
              <div className="flex items-center space-x-2 mb-3">
                <Input
                  value={highlightTitle}
                  onChange={(e) => setHighlightTitle(e.target.value)}
                  placeholder="Highlight name"
                  className="rounded-xl"
                />
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={saveHighlight}
                  className="bg-primary hover:bg-primary/90 rounded-xl"
                >
                  Add
                </Button>
              </div>
              <div className="flex items-center space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="rounded-xl"
                  onClick={() => highlightImageRef.current?.click()}
                >
                  <Camera size={16} className="mr-1" />
                  Choose Cover
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowAddHighlight(false)}
                  className="text-gray-500 rounded-xl"
                >
                  Cancel
                </Button>
                <input 
                  type="file" 
                  ref={highlightImageRef}
                  className="hidden" 
                  accept="image/*"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-6">
        <h3 className="text-lg font-medium mb-3">Account Settings</h3>
        <Card className="phantom-card">
          <div className="divide-y divide-gray-100">
            <div className="p-4 hover:bg-gray-50/50 cursor-pointer flex items-center justify-between">
              <div className="flex items-center">
                <Lock className="h-5 w-5 text-gray-500 mr-3" />
                <p className="font-medium">Change Password</p>
              </div>
              <div className="text-gray-400">
                <ArrowLeft className="rotate-180 h-4 w-4" />
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50/50 cursor-pointer flex items-center justify-between">
              <div className="flex items-center">
                <ShieldAlert className="h-5 w-5 text-gray-500 mr-3" />
                <p className="font-medium">Privacy Settings</p>
              </div>
              <div className="text-gray-400">
                <ArrowLeft className="rotate-180 h-4 w-4" />
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50/50 cursor-pointer flex items-center justify-between">
              <div className="flex items-center">
                <Bell className="h-5 w-5 text-gray-500 mr-3" />
                <p className="font-medium">Notification Preferences</p>
              </div>
              <div className="text-gray-400">
                <ArrowLeft className="rotate-180 h-4 w-4" />
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50/50 cursor-pointer flex items-center justify-between">
              <div className="flex items-center">
                <Moon className="h-5 w-5 text-gray-500 mr-3" />
                <p className="font-medium">Dark Mode</p>
              </div>
              <div className="text-gray-400">
                <ArrowLeft className="rotate-180 h-4 w-4" />
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50/50 cursor-pointer flex items-center justify-between">
              <div className="flex items-center">
                <HelpCircle className="h-5 w-5 text-gray-500 mr-3" />
                <p className="font-medium">Help Center</p>
              </div>
              <div className="text-gray-400">
                <ArrowLeft className="rotate-180 h-4 w-4" />
              </div>
            </div>
            <div className="p-4 hover:bg-gray-50/50 cursor-pointer flex items-center text-red-500">
              <LogOut className="h-5 w-5 mr-3" />
              <p className="font-medium">Log Out</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ProfileEdit;
