
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Image, Video, Mic, Radio, Presentation, FileText, BarChart, Calendar, Sparkles } from "lucide-react";
import CreateContent from "@/components/sence/CreateContent";
import ReelUpload from "@/components/sence/ReelUpload";
import { useToast } from "@/components/ui/use-toast";

const CreatePage = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("post");
  const { toast } = useToast();
  
  const handleComplete = () => {
    toast({
      title: "Success!",
      description: "Your content has been created successfully.",
    });
    navigate("/");
  };
  
  // These would be implemented in a real application
  const NotImplementedTab = ({ type }: { type: string }) => (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
      <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
        {type === "audio" && <Mic className="h-6 w-6 text-primary" />}
        {type === "live" && <Radio className="h-6 w-6 text-primary" />}
        {type === "story" && <Presentation className="h-6 w-6 text-primary" />}
        {type === "article" && <FileText className="h-6 w-6 text-primary" />}
        {type === "poll" && <BarChart className="h-6 w-6 text-primary" />}
        {type === "event" && <Calendar className="h-6 w-6 text-primary" />}
      </div>
      <h3 className="text-xl font-bold mb-2">Create {type.charAt(0).toUpperCase() + type.slice(1)}</h3>
      <p className="text-gray-500 mb-6 max-w-sm">
        This feature is coming soon! Subscribe to our premium plan to be the first to access when it launches.
      </p>
      <Button variant="outline" className="gap-2">
        <Sparkles className="h-4 w-4" />
        Premium Features
      </Button>
    </div>
  );
  
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      <header className="sticky top-0 z-10 bg-white dark:bg-gray-800 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center max-w-2xl">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate(-1)}
            className="mr-4 h-9 w-9"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            Create New Content
          </h1>
        </div>
      </header>
      
      <div className="container mx-auto px-4 max-w-2xl">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="grid grid-cols-4 mb-8">
            <TabsTrigger value="post" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Image className="h-4 w-4 mr-1" /> Post
            </TabsTrigger>
            <TabsTrigger value="reel" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Video className="h-4 w-4 mr-1" /> Reel
            </TabsTrigger>
            <TabsTrigger value="story" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Presentation className="h-4 w-4 mr-1" /> Story
            </TabsTrigger>
            <TabsTrigger value="more" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              More
            </TabsTrigger>
          </TabsList>

          <TabsContent value="post">
            <CreateContent />
          </TabsContent>
          
          <TabsContent value="reel">
            <ReelUpload onComplete={handleComplete} />
          </TabsContent>
          
          <TabsContent value="story">
            <NotImplementedTab type="story" />
          </TabsContent>
          
          <TabsContent value="more">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4">
              <Button variant="outline" className="h-auto py-6 flex-col gap-2" onClick={() => setActiveTab("audio")}>
                <Mic className="h-6 w-6" />
                <span>Audio</span>
              </Button>
              
              <Button variant="outline" className="h-auto py-6 flex-col gap-2" onClick={() => setActiveTab("live")}>
                <Radio className="h-6 w-6" />
                <span>Go Live</span>
              </Button>
              
              <Button variant="outline" className="h-auto py-6 flex-col gap-2" onClick={() => setActiveTab("article")}>
                <FileText className="h-6 w-6" />
                <span>Article</span>
              </Button>
              
              <Button variant="outline" className="h-auto py-6 flex-col gap-2" onClick={() => setActiveTab("poll")}>
                <BarChart className="h-6 w-6" />
                <span>Poll</span>
              </Button>
              
              <Button variant="outline" className="h-auto py-6 flex-col gap-2" onClick={() => setActiveTab("event")}>
                <Calendar className="h-6 w-6" />
                <span>Event</span>
              </Button>
              
              <Button variant="outline" className="h-auto py-6 flex-col gap-2 opacity-50" disabled>
                <Sparkles className="h-6 w-6" />
                <span>Coming Soon</span>
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="audio">
            <NotImplementedTab type="audio" />
          </TabsContent>
          
          <TabsContent value="live">
            <NotImplementedTab type="live" />
          </TabsContent>
          
          <TabsContent value="article">
            <NotImplementedTab type="article" />
          </TabsContent>
          
          <TabsContent value="poll">
            <NotImplementedTab type="poll" />
          </TabsContent>
          
          <TabsContent value="event">
            <NotImplementedTab type="event" />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CreatePage;
