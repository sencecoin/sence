
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { GameProvider } from "@/context/GameContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ProfileEdit from "./pages/ProfileEdit";
import ChatDetail from "./pages/ChatDetail";
import UserProfile from "./pages/UserProfile";
import CreatePage from "./pages/CreatePage";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
      staleTime: 5 * 60 * 1000,
    },
  },
});

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <GameProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/profile/edit" element={<ProfileEdit />} />
              <Route path="/profile/:userId" element={<UserProfile />} />
              <Route path="/chat/:userId" element={<ChatDetail />} />
              <Route path="/create" element={<CreatePage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </GameProvider>
    </QueryClientProvider>
  );
};

export default App;
