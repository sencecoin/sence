
import { useState, useRef, useEffect } from "react";
import { useGameContext } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { Image, Video, Mic, MapPin, Smile, X, Clock, Eye, Sparkles, Hash, Clipboard, Trash2, PenSquare, Filter, Cloud, Layout, Target, LayoutGrid, Gift, Calendar, BookOpen, AlignJustify, Network, Coins } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import EmojiPicker from "@/components/sence/EmojiPicker";
import ContentTemplates from "@/components/sence/ContentTemplates";
import MediaFilters from "@/components/sence/MediaFilters";
import AudienceSelector from "@/components/sence/AudienceSelector";

const CreateContent = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [topic, setTopic] = useState("");
  const [caption, setCaption] = useState("");
  const [selectedHashtags, setSelectedHashtags] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [filter, setFilter] = useState("original");
  const [location, setLocation] = useState("");
  const [audienceType, setAudienceType] = useState("public");
  const [scheduledTime, setScheduledTime] = useState<Date | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [mediaType, setMediaType] = useState<"photo" | "video">("photo");
  const [description, setDescription] = useState("");
  const [isAdvancedMode, setIsAdvancedMode] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [showTemplates, setShowTemplates] = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [tags, setTags] = useState<string[]>([]);
  const [isTaggingPeople, setIsTaggingPeople] = useState(false);
  const [showRatingInfo, setShowRatingInfo] = useState(false);
  const [allowComments, setAllowComments] = useState(true);
  const [allowLikes, setAllowLikes] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [savedAsDraft, setSavedAsDraft] = useState(false);
  const [currentTab, setCurrentTab] = useState("upload");
  const [reachedCharLimit, setReachedCharLimit] = useState(false);
  
  const { availableTopics, availableHashtags, addPost, currentUser } = useGameContext();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioRecorderRef = useRef<any>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);
  
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setMediaType("photo");
        handleMediaSelection(file);
      } else if (file.type.startsWith('video/')) {
        setMediaType("video");
        handleMediaSelection(file);
      } else {
        toast({
          title: "Invalid file type",
          description: "Please select an image or video file",
          variant: "destructive",
        });
      }
    }
  };

  const handleMediaSelection = (file: File) => {
    setSelectedFile(file);
    const fileUrl = URL.createObjectURL(file);
    setPreviewUrl(fileUrl);
    
    toast({
      title: "File selected",
      description: `Your ${file.type.startsWith('image/') ? 'image' : 'video'} has been selected. Add details to complete your post.`,
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setMediaType("photo");
        handleMediaSelection(file);
      } else if (file.type.startsWith('video/')) {
        setMediaType("video");
        handleMediaSelection(file);
      } else {
        toast({
          title: "Invalid file type",
          description: "Please select an image or video file",
          variant: "destructive",
        });
      }
    }
  };
  
  const startAudioRecording = () => {
    setIsRecordingAudio(true);
    setRecordingTime(0);
    
    // Start timer
    timerRef.current = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
    
    toast({
      title: "Recording started",
      description: "Speak clearly into your microphone",
    });
  };
  
  const stopAudioRecording = () => {
    setIsRecordingAudio(false);
    
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    
    toast({
      title: "Recording stopped",
      description: `Audio recorded for ${formatTime(recordingTime)}`,
    });
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleHashtagToggle = (tag: string) => {
    if (selectedHashtags.includes(tag)) {
      setSelectedHashtags(selectedHashtags.filter((t) => t !== tag));
    } else {
      setSelectedHashtags([...selectedHashtags, tag]);
    }
  };
  
  const addCustomHashtag = (value: string) => {
    if (value && !value.startsWith('#')) {
      value = '#' + value;
    }
    
    if (value && !selectedHashtags.includes(value)) {
      setSelectedHashtags([...selectedHashtags, value]);
    }
  };
  
  const handleEmojiSelect = (emoji: string) => {
    setCaption(caption + emoji);
    setShowEmojiPicker(false);
  };
  
  const selectTemplate = (template: string) => {
    setSelectedTemplate(template);
    setCaption(template);
    setShowTemplates(false);
  };
  
  const saveDraft = () => {
    setSavedAsDraft(true);
    toast({
      title: "Draft saved",
      description: "Your post has been saved as a draft",
    });
  };
  
  const handleFilterSelect = (newFilter: string) => {
    setFilter(newFilter);
    toast({
      title: "Filter applied",
      description: `${newFilter} filter has been applied to your media`,
    });
  };

  const clearSelection = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setSelectedFile(null);
    setPreviewUrl(null);
    setMediaType("photo");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSubmit = async (e: React.FormEvent, isDraft: boolean = false) => {
    e.preventDefault();
    
    if (!selectedFile && !isDraft) {
      toast({
        title: "No file selected",
        description: "Please select an image or video to upload",
        variant: "destructive",
      });
      return;
    }

    if (isDraft) {
      saveDraft();
      return;
    }
    
    setIsSaving(true);

    try {
      // Create a base64 string from the file
      if (selectedFile) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64String = reader.result as string;
          
          addPost({
            type: mediaType,
            topic,
            caption,
            hashtags: selectedHashtags,
            imageUrl: mediaType === 'photo' ? base64String : undefined,
            videoUrl: mediaType === 'video' ? base64String : undefined,
          });

          // Reset form
          setSelectedFile(null);
          setPreviewUrl(null);
          setTopic("");
          setCaption("");
          setSelectedHashtags([]);
          setIsSaving(false);
          setLocation("");
          setDescription("");
          setFilter("original");
          setBrightness(100);
          setContrast(100);
          setSaturation(100);
          setTags([]);

          toast({
            title: "Success!",
            description: "Your post has been created",
          });
        };
        reader.readAsDataURL(selectedFile);
      } else {
        setIsSaving(false);
      }
    } catch (error) {
      setIsSaving(false);
      toast({
        title: "Error",
        description: "An error occurred while creating your post",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">Create New Content</h1>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Share photos, videos, and your thoughts with your followers
        </p>
        
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="mt-4">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="upload" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Image className="h-4 w-4 mr-1" /> Upload
            </TabsTrigger>
            <TabsTrigger value="templates" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Layout className="h-4 w-4 mr-1" /> Templates
            </TabsTrigger>
            <TabsTrigger value="advanced" className="data-[state=active]:bg-primary data-[state=active]:text-white">
              <Sparkles className="h-4 w-4 mr-1" /> Advanced
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div 
                className={`border-2 ${isDragging ? 'border-primary' : 'border-dashed'} border-gray-300 dark:border-gray-700 rounded-lg p-4 transition-colors duration-200 relative`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <input
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                  ref={fileInputRef}
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer block text-center"
                >
                  {previewUrl ? (
                    <div className="relative">
                      <div className="aspect-square rounded-lg overflow-hidden">
                        {mediaType === 'photo' ? (
                          <img
                            src={previewUrl}
                            alt="Preview"
                            className="w-full h-full object-cover"
                            style={{
                              filter: `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`
                            }}
                          />
                        ) : (
                          <video
                            src={previewUrl}
                            className="w-full h-full object-cover"
                            controls
                          />
                        )}
                      </div>
                      <div className="absolute top-2 right-2 flex gap-2">
                        <Button
                          type="button"
                          size="icon"
                          variant="outline"
                          className="h-8 w-8 rounded-full bg-white dark:bg-gray-800"
                          onClick={() => setShowFilters(!showFilters)}
                        >
                          <Filter className="h-4 w-4" />
                        </Button>
                        <Button
                          type="button"
                          size="icon"
                          variant="destructive"
                          className="h-8 w-8 rounded-full"
                          onClick={clearSelection}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="aspect-square flex items-center justify-center">
                      <div className="text-center">
                        <div className="flex justify-center mb-4">
                          <Image className="h-12 w-12 text-gray-400 mr-2" />
                          <Video className="h-12 w-12 text-gray-400" />
                        </div>
                        <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                          Click to upload image or video
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          Or drag and drop files here
                        </p>
                      </div>
                    </div>
                  )}
                </label>
              </div>

              {showFilters && mediaType === 'photo' && previewUrl && (
                <div className="space-y-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-800">
                  <h3 className="font-medium mb-2">Image Adjustments</h3>
                  
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="brightness">Brightness</Label>
                        <span className="text-xs text-gray-500">{brightness}%</span>
                      </div>
                      <Slider
                        id="brightness"
                        min={0}
                        max={200}
                        step={1}
                        value={[brightness]}
                        onValueChange={(value) => setBrightness(value[0])}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="contrast">Contrast</Label>
                        <span className="text-xs text-gray-500">{contrast}%</span>
                      </div>
                      <Slider
                        id="contrast"
                        min={0}
                        max={200}
                        step={1}
                        value={[contrast]}
                        onValueChange={(value) => setContrast(value[0])}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <Label htmlFor="saturation">Saturation</Label>
                        <span className="text-xs text-gray-500">{saturation}%</span>
                      </div>
                      <Slider
                        id="saturation"
                        min={0}
                        max={200}
                        step={1}
                        value={[saturation]}
                        onValueChange={(value) => setSaturation(value[0])}
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 flex-wrap mt-2">
                    <Button 
                      type="button" 
                      size="sm" 
                      variant={filter === "original" ? "default" : "outline"} 
                      onClick={() => handleFilterSelect("original")}
                    >
                      Original
                    </Button>
                    <Button 
                      type="button" 
                      size="sm" 
                      variant={filter === "grayscale" ? "default" : "outline"} 
                      onClick={() => {
                        setFilter("grayscale");
                        setSaturation(0);
                      }}
                    >
                      B&W
                    </Button>
                    <Button 
                      type="button" 
                      size="sm" 
                      variant={filter === "sepia" ? "default" : "outline"} 
                      onClick={() => {
                        setFilter("sepia");
                        setSaturation(120);
                        setBrightness(90);
                      }}
                    >
                      Vintage
                    </Button>
                    <Button 
                      type="button" 
                      size="sm" 
                      variant={filter === "vivid" ? "default" : "outline"} 
                      onClick={() => {
                        setFilter("vivid");
                        setSaturation(150);
                        setContrast(120);
                      }}
                    >
                      Vivid
                    </Button>
                    <Button 
                      type="button" 
                      size="sm" 
                      variant={filter === "dramatic" ? "default" : "outline"} 
                      onClick={() => {
                        setFilter("dramatic");
                        setContrast(150);
                        setBrightness(90);
                      }}
                    >
                      Dramatic
                    </Button>
                  </div>
                </div>
              )}

              <div>
                <div className="flex justify-between mb-1">
                  <Label htmlFor="topic" className="text-sm font-medium">
                    Topic
                  </Label>
                  {topic && (
                    <span className="text-xs text-primary">Selected: {topic}</span>
                  )}
                </div>
                <select
                  id="topic"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full p-2 border rounded-md dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-primary focus:border-primary"
                  required
                >
                  <option value="">Select a topic</option>
                  {availableTopics.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="caption" className="text-sm font-medium">
                    Caption
                  </Label>
                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7"
                      onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    >
                      <Smile className="h-4 w-4" />
                    </Button>
                    <span className={`text-xs ${caption.length > 2000 ? 'text-red-500' : 'text-gray-500'}`}>
                      {caption.length}/2200
                    </span>
                  </div>
                </div>

                <div className="relative">
                  <textarea
                    id="caption"
                    value={caption}
                    onChange={(e) => {
                      setCaption(e.target.value);
                      setReachedCharLimit(e.target.value.length >= 2200);
                    }}
                    className="w-full p-3 border rounded-md dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-primary focus:border-primary"
                    rows={4}
                    placeholder="Write a caption for your post..."
                    maxLength={2200}
                    required
                  ></textarea>

                  {showEmojiPicker && (
                    <div className="absolute z-10 right-0 mt-1">
                      <EmojiPicker onSelect={handleEmojiSelect} />
                    </div>
                  )}
                </div>

                {reachedCharLimit && (
                  <p className="text-xs text-red-500">
                    You've reached the maximum character limit.
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label className="text-sm font-medium flex justify-between w-full">
                    <span>Hashtags</span>
                    <span className="text-xs text-gray-500">
                      {selectedHashtags.length} selected
                    </span>
                  </Label>
                </div>

                <div className="flex flex-wrap gap-2 mb-2">
                  {selectedHashtags.map((tag) => (
                    <div
                      key={tag}
                      className="bg-primary/10 text-primary dark:bg-primary/20 dark:text-primary-foreground px-2 py-1 rounded-md text-sm flex items-center"
                    >
                      {tag}
                      <button
                        type="button"
                        onClick={() =>
                          setSelectedHashtags(
                            selectedHashtags.filter((t) => t !== tag)
                          )
                        }
                        className="ml-1 text-primary hover:text-primary/70 focus:outline-none"
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <select
                    value=""
                    onChange={(e) => {
                      if (e.target.value && !selectedHashtags.includes(e.target.value)) {
                        setSelectedHashtags([...selectedHashtags, e.target.value]);
                      }
                      e.target.value = "";
                    }}
                    className="w-full p-2 border rounded-md dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-primary focus:border-primary"
                  >
                    <option value="">Add a hashtag</option>
                    {availableHashtags
                      .filter((tag) => !selectedHashtags.includes(tag))
                      .map((tag) => (
                        <option key={tag} value={tag}>
                          {tag}
                        </option>
                      ))}
                  </select>

                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="icon">
                        <Hash className="h-4 w-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80">
                      <div className="space-y-2">
                        <h4 className="font-medium">Add custom hashtag</h4>
                        <div className="flex gap-2">
                          <Input 
                            placeholder="Type a hashtag..."
                            id="custom-hashtag"
                          />
                          <Button 
                            onClick={() => {
                              const input = document.getElementById('custom-hashtag') as HTMLInputElement;
                              if (input && input.value) {
                                addCustomHashtag(input.value);
                                input.value = '';
                              }
                            }}
                          >
                            Add
                          </Button>
                        </div>
                        <p className="text-xs text-gray-500">
                          Add your own hashtags to increase post visibility
                        </p>
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="location" className="text-sm font-medium">
                  Add Location (optional)
                </Label>
                <div className="flex">
                  <Input
                    id="location"
                    placeholder="Add a location..."
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="ml-2"
                    onClick={() => {
                      // Would use geolocation in a real app
                      setLocation("Current Location");
                      toast({
                        title: "Location added",
                        description: "Current location has been added to your post",
                      });
                    }}
                  >
                    <MapPin className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Button 
                  type="button"
                  variant="outline" 
                  className="w-full"
                  onClick={(e) => handleSubmit(e, true)}
                >
                  Save as Draft
                </Button>
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Uploading...
                    </>
                  ) : (
                    'Create Post'
                  )}
                </Button>
              </div>
            </form>
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <ContentTemplates onTemplateSelect={selectTemplate} />
          </TabsContent>

          <TabsContent value="advanced" className="space-y-6">
            <div className="space-y-6">
              <Card className="p-4">
                <h3 className="font-semibold mb-2 text-lg flex items-center">
                  <Target className="h-4 w-4 mr-2" /> 
                  Audience Settings
                </h3>
                <AudienceSelector value={audienceType} onChange={setAudienceType} />
                
                <div className="space-y-3 mt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="allow-comments" className="font-medium">Allow comments</Label>
                      <p className="text-xs text-gray-500">Let people comment on your post</p>
                    </div>
                    <Switch
                      id="allow-comments"
                      checked={allowComments}
                      onCheckedChange={setAllowComments}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="allow-likes" className="font-medium">Allow likes</Label>
                      <p className="text-xs text-gray-500">Let people like your post</p>
                    </div>
                    <Switch
                      id="allow-likes"
                      checked={allowLikes}
                      onCheckedChange={setAllowLikes}
                    />
                  </div>
                </div>
              </Card>
              
              <Card className="p-4">
                <h3 className="font-semibold mb-2 text-lg flex items-center">
                  <Clock className="h-4 w-4 mr-2" /> 
                  Schedule Post
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="schedule-post" className="font-medium">Post later</Label>
                      <p className="text-xs text-gray-500">Schedule your post for the future</p>
                    </div>
                    <Switch
                      id="schedule-post"
                      checked={!!scheduledTime}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          // Set to tomorrow at current time
                          const tomorrow = new Date();
                          tomorrow.setDate(tomorrow.getDate() + 1);
                          setScheduledTime(tomorrow);
                        } else {
                          setScheduledTime(null);
                        }
                      }}
                    />
                  </div>
                  
                  {scheduledTime && (
                    <div className="mt-2">
                      <Label htmlFor="schedule-time" className="text-sm font-medium block mb-1">
                        Schedule time
                      </Label>
                      <Input
                        id="schedule-time"
                        type="datetime-local"
                        value={scheduledTime.toISOString().slice(0, 16)}
                        onChange={(e) => {
                          const newTime = new Date(e.target.value);
                          setScheduledTime(newTime);
                        }}
                        className="w-full"
                      />
                      <p className="text-xs text-primary mt-1">
                        Your post will be published automatically at this time
                      </p>
                    </div>
                  )}
                </div>
              </Card>
              
              <Card className="p-4">
                <h3 className="font-semibold mb-2 text-lg flex items-center">
                  <Coins className="h-4 w-4 mr-2" /> 
                  Premium Features
                  <span className="ml-2 px-2 py-0.5 rounded-full text-xs bg-primary text-white">PRO</span>
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between opacity-60">
                    <div>
                      <Label htmlFor="boost-post" className="font-medium">Boost Post</Label>
                      <p className="text-xs text-gray-500">Increase visibility with Sence Coins</p>
                    </div>
                    <Switch
                      id="boost-post"
                      disabled
                    />
                  </div>
                  
                  <div className="flex items-center justify-between opacity-60">
                    <div>
                      <Label htmlFor="analytics" className="font-medium">Advanced Analytics</Label>
                      <p className="text-xs text-gray-500">Get detailed insights on your post performance</p>
                    </div>
                    <Switch
                      id="analytics"
                      disabled
                    />
                  </div>
                  
                  <Button 
                    variant="outline" 
                    className="w-full mt-2"
                    disabled
                  >
                    <Gift className="h-4 w-4 mr-2" />
                    Upgrade to Pro
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CreateContent;
