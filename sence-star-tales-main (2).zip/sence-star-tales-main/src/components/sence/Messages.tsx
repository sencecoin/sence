
import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useGameContext } from "@/context/GameContext";
import { User, Send, Search, Phone, Video, Image, Mic, MessageCircle, ArrowLeft, Filter, Globe, Lock, Bell, UserPlus, Sparkles } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { Avatar } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

const Messages = () => {
  const navigate = useNavigate();
  const { users, currentUser, getConversations } = useGameContext();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"chats" | "calls" | "requests">("chats");
  const [searchQuery, setSearchQuery] = useState("");
  const [conversations, setConversations] = useState<any[]>([]);
  const [messageRequests, setMessageRequests] = useState<any[]>([]);
  const [filteredOptions, setFilteredOptions] = useState<"all" | "unread" | "online">("all");
  const [isAddContactOpen, setIsAddContactOpen] = useState(false);
  
  // Get conversations and set them
  useEffect(() => {
    if (currentUser) {
      const userConversations = getConversations();
      setConversations(userConversations.map(conv => {
        const otherParticipantId = conv.participants.find(id => id !== currentUser.id);
        const otherUser = users.find(user => user.id === otherParticipantId);
        
        return {
          ...conv,
          name: otherUser ? otherUser.username : 'Unknown User',
          online: Math.random() > 0.5, // Random online status for demo
          lastActive: new Date(Date.now() - Math.floor(Math.random() * 10000000)),
          typing: Math.random() > 0.9, // Random typing status for demo
        };
      }));
      
      // Generate some message requests for demo
      setMessageRequests(
        users
          .filter(user => !currentUser.following.includes(user.id) && user.id !== currentUser.id)
          .slice(0, 3)
          .map(user => ({
            id: `req-${user.id}`,
            user,
            message: "Hello! I'd like to connect with you.",
            timestamp: new Date(Date.now() - Math.floor(Math.random() * 10000000)),
          }))
      );
    }
  }, [currentUser, users, getConversations]);
  
  const formatChatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const dayInMs = 86400000;
    
    if (diff < dayInMs) {
      return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diff < dayInMs * 2) {
      return "Yesterday";
    } else if (diff < dayInMs * 7) {
      return new Date(date).toLocaleDateString([], { weekday: 'short' });
    } else {
      return new Date(date).toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };
  
  const formatLastActive = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minuteInMs = 60000;
    const hourInMs = 3600000;
    const dayInMs = 86400000;
    
    if (diff < minuteInMs) {
      return "Just now";
    } else if (diff < hourInMs) {
      return `${Math.floor(diff / minuteInMs)}m ago`;
    } else if (diff < dayInMs) {
      return `${Math.floor(diff / hourInMs)}h ago`;
    } else {
      return formatChatTime(date);
    }
  };
  
  // Filter users based on search query and filter options
  const filteredUsers = users.filter(user => {
    if (currentUser && user.id === currentUser.id) return false;
    
    const matchesSearch = user.username.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesSearch;
  });
  
  // Filter conversations based on search query and filter options
  const filteredConversations = conversations.filter(conv => {
    // Filter by search query
    const matchesSearch = conv.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Apply additional filters
    if (filteredOptions === "unread" && conv.unread === 0) return false;
    if (filteredOptions === "online" && !conv.online) return false;
    
    return matchesSearch;
  });
  
  const handleStartChat = (userId: string) => {
    navigate(`/chat/${userId}`);
  };
  
  const handleAcceptRequest = (requestId: string) => {
    // Find the request
    const request = messageRequests.find(req => req.id === requestId);
    if (!request) return;
    
    // Accept the request and start a conversation
    handleStartChat(request.user.id);
    
    // Remove from requests
    setMessageRequests(prev => prev.filter(req => req.id !== requestId));
    
    toast({
      title: "Request accepted",
      description: `You are now connected with ${request.user.username}`,
    });
  };
  
  const handleDeclineRequest = (requestId: string) => {
    // Remove the request
    setMessageRequests(prev => prev.filter(req => req.id !== requestId));
    
    toast({
      title: "Request declined",
      description: "The message request has been removed",
    });
  };
  
  if (!currentUser) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-gray-500">
        <p className="text-center">Please log in to use messages.</p>
      </div>
    );
  }
  
  return (
    <div className="pb-20">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          {isAddContactOpen ? (
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setIsAddContactOpen(false)}
              className="mr-2"
            >
              <ArrowLeft size={20} />
            </Button>
          ) : (
            <h2 className="text-lg font-semibold">Messages</h2>
          )}
        </div>
        <div className="flex">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <Filter size={18} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setFilteredOptions("all")}>
                <Globe className="w-4 h-4 mr-2" /> All messages
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilteredOptions("unread")}>
                <Bell className="w-4 h-4 mr-2" /> Unread
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilteredOptions("online")}>
                <User className="w-4 h-4 mr-2" /> Online
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setIsAddContactOpen(!isAddContactOpen)}
          >
            <UserPlus size={18} />
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="chats" onValueChange={(v) => setActiveTab(v as "chats" | "calls" | "requests")}>
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="chats">Chats</TabsTrigger>
          <TabsTrigger value="calls">Calls</TabsTrigger>
          <TabsTrigger value="requests" className="relative">
            Requests
            {messageRequests.length > 0 && (
              <Badge className="absolute -top-1 -right-1 bg-red-500 h-5 w-5 p-0 flex items-center justify-center">
                {messageRequests.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="chats" className="space-y-4">
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input
                placeholder="Search messages or users"
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          {isAddContactOpen ? (
            <div className="space-y-4 animate-fade-in">
              <h3 className="font-medium text-sm text-gray-500 px-1">SUGGESTED CONTACTS</h3>
              <div className="space-y-2">
                {filteredUsers.map((user) => (
                  <div 
                    key={user.id} 
                    className="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors"
                    onClick={() => handleStartChat(user.id)}
                  >
                    <div className="relative">
                      <Avatar className="h-12 w-12">
                        {user.profileImage ? (
                          <img 
                            src={user.profileImage} 
                            alt={user.username} 
                            className="h-full w-full object-cover rounded-full" 
                          />
                        ) : (
                          <div className="bg-gradient-to-br from-blue-500 to-purple-600 text-white flex items-center justify-center h-full w-full rounded-full">
                            {user.username.charAt(0).toUpperCase()}
                          </div>
                        )}
                      </Avatar>
                      {user.isVerified && (
                        <div className="absolute bottom-0 right-0 h-4 w-4 bg-blue-500 rounded-full border border-white flex items-center justify-center">
                          <span className="text-white text-[8px]">✓</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="ml-3 flex-1">
                      <div className="flex items-center">
                        <h3 className="font-medium text-gray-800">{user.username}</h3>
                        {user.isVerified && (
                          <span className="ml-1 text-blue-500 text-xs">•</span>
                        )}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <p className="truncate">{user.bio}</p>
                      </div>
                    </div>
                    
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="ml-2 bg-transparent border border-gray-200 text-blue-500 hover:bg-blue-50 hover:text-blue-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStartChat(user.id);
                      }}
                    >
                      Message
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {messageRequests.length > 0 && activeTab === "chats" && (
                <div className="border border-gray-200 rounded-lg p-3 bg-blue-50/50 mb-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium text-blue-600">Message Requests</h3>
                      <p className="text-sm text-gray-600">You have {messageRequests.length} new message requests</p>
                    </div>
                    <Button 
                      variant="link" 
                      className="text-blue-500 p-0 h-auto"
                      onClick={() => setActiveTab("requests")}
                    >
                      View All
                    </Button>
                  </div>
                </div>
              )}
              
              {filteredConversations.length > 0 && (
                <div className="space-y-2">
                  {filteredOptions !== "all" && (
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium text-sm text-gray-500 px-1">
                        {filteredOptions === "unread" ? "UNREAD MESSAGES" : "ONLINE FRIENDS"}
                      </h3>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs h-6 px-2"
                        onClick={() => setFilteredOptions("all")}
                      >
                        Clear Filter
                      </Button>
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    {filteredConversations.map((conv) => (
                      <div 
                        key={conv.id} 
                        className={`flex items-center p-3 border rounded-lg transition-colors ${
                          conv.unread > 0 
                            ? "border-blue-200 bg-blue-50 hover:bg-blue-100" 
                            : "border-gray-200 hover:bg-gray-50"
                        } cursor-pointer`}
                        onClick={() => {
                          const otherUserId = conv.participants.find((id: string) => id !== currentUser?.id);
                          handleStartChat(otherUserId);
                        }}
                      >
                        <div className="relative">
                          <Avatar className="h-14 w-14">
                            <div className={`${
                              Math.random() > 0.5 ? 'bg-gradient-to-br from-blue-500 to-purple-600' : 'bg-gradient-to-br from-pink-500 to-rose-500'
                            } text-white flex items-center justify-center h-full w-full rounded-full text-lg`}>
                              {conv.name.charAt(0).toUpperCase()}
                            </div>
                          </Avatar>
                          {conv.online && (
                            <div className="absolute bottom-0 right-0 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></div>
                          )}
                          
                          {/* Story ring for users with stories (random for demo) */}
                          {Math.random() > 0.7 && (
                            <div className="absolute inset-0 rounded-full border-2 border-transparent bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 -m-0.5" style={{ maskImage: 'radial-gradient(transparent 60%, black 62%)', WebkitMaskImage: 'radial-gradient(transparent 60%, black 62%)' }}></div>
                          )}
                        </div>
                        
                        <div className="ml-3 flex-1">
                          <div className="flex justify-between items-center">
                            <h3 className="font-medium text-gray-800">{conv.name}</h3>
                            <span className="text-xs text-gray-500">{formatChatTime(conv.timestamp)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <p className={`text-sm truncate ${conv.unread > 0 ? "font-medium text-gray-800" : "text-gray-500"}`}>
                              {conv.typing ? (
                                <span className="text-blue-500 flex items-center">
                                  <span className="mr-1">Typing</span>
                                  <span className="flex items-center">
                                    <span className="animate-pulse">.</span>
                                    <span className="animate-pulse" style={{ animationDelay: "0.2s" }}>.</span>
                                    <span className="animate-pulse" style={{ animationDelay: "0.4s" }}>.</span>
                                  </span>
                                </span>
                              ) : conv.lastMessage}
                            </p>
                            {conv.unread > 0 && (
                              <Badge className="bg-blue-500">{conv.unread}</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {filteredConversations.length === 0 && !searchQuery && (
                <div className="text-center py-10">
                  <div className="bg-gray-100 h-20 w-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="h-10 w-10 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-700 mb-1">Your messages</h3>
                  <p className="text-gray-500 mb-4">Send private messages to friends</p>
                  <Button 
                    onClick={() => setIsAddContactOpen(true)}
                    className="bg-gradient-to-r from-blue-500 to-blue-600"
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                </div>
              )}
              
              {filteredConversations.length === 0 && searchQuery && (
                <div className="text-center py-10">
                  <Search className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500">No results found for "{searchQuery}"</p>
                  <Button
                    variant="link"
                    className="mt-2 text-blue-500"
                    onClick={() => setSearchQuery("")}
                  >
                    Clear search
                  </Button>
                </div>
              )}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="calls" className="space-y-4">
          <Card className="p-6 text-center border-gray-200 shadow-sm">
            <div className="mb-4 relative mx-auto w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
              <Video className="h-10 w-10 text-white" />
              <div className="absolute -right-1 -bottom-1 h-8 w-8 bg-white rounded-full flex items-center justify-center shadow-md">
                <Sparkles className="h-4 w-4 text-yellow-500" />
              </div>
            </div>
            <h3 className="text-xl font-semibold mb-2">Video Chat with Friends</h3>
            <p className="text-gray-500 mb-6">Connect instantly with high-quality video and voice calls</p>
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="border-blue-200 text-blue-600"
                onClick={() => {
                  toast({
                    title: "Select a user",
                    description: "Please select a user from the chats tab to call",
                  });
                  setActiveTab("chats");
                }}
              >
                <Phone className="mr-2 h-4 w-4" /> Voice Call
              </Button>
              <Button 
                className="bg-gradient-to-r from-blue-500 to-blue-600"
                onClick={() => {
                  toast({
                    title: "Select a user",
                    description: "Please select a user from the chats tab to call",
                  });
                  setActiveTab("chats");
                }}
              >
                <Video className="mr-2 h-4 w-4" /> Video Call
              </Button>
            </div>
          </Card>
          
          <div className="space-y-2">
            <h3 className="font-medium text-gray-800 mb-2">Recent Calls</h3>
            <div className="text-center py-6">
              <p className="text-gray-500">No recent calls</p>
              <p className="text-sm text-gray-400 mt-2">Your call history will appear here</p>
            </div>
          </div>
          
          <Card className="p-4 border-gray-200 mt-4">
            <h3 className="font-medium mb-3">Call Features</h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                  <Lock className="h-4 w-4 text-blue-600" />
                </div>
                <span>End-to-end encryption</span>
              </div>
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                  <User className="h-4 w-4 text-green-600" />
                </div>
                <span>Up to 8 participants</span>
              </div>
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center mr-2">
                  <Image className="h-4 w-4 text-purple-600" />
                </div>
                <span>Screen sharing</span>
              </div>
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center mr-2">
                  <Filter className="h-4 w-4 text-orange-600" />
                </div>
                <span>AR filters</span>
              </div>
            </div>
          </Card>
        </TabsContent>
        
        <TabsContent value="requests" className="space-y-4">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-medium text-lg">Message Requests</h3>
            {messageRequests.length > 0 && (
              <Badge className="bg-blue-500">{messageRequests.length}</Badge>
            )}
          </div>
          
          {messageRequests.length > 0 ? (
            <div className="space-y-3">
              {messageRequests.map((request) => (
                <div key={request.id} className="border border-gray-200 rounded-lg p-4 bg-white">
                  <div className="flex items-start">
                    <Avatar className="h-12 w-12">
                      {request.user.profileImage ? (
                        <img 
                          src={request.user.profileImage} 
                          alt={request.user.username} 
                          className="h-full w-full object-cover rounded-full" 
                        />
                      ) : (
                        <div className="bg-gradient-to-br from-purple-500 to-pink-600 text-white flex items-center justify-center h-full w-full rounded-full">
                          {request.user.username.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </Avatar>
                    
                    <div className="ml-3 flex-1">
                      <div className="flex items-center">
                        <h3 className="font-medium text-gray-800">{request.user.username}</h3>
                        {request.user.isVerified && (
                          <Badge className="ml-2 bg-blue-500 h-4 px-1 text-[10px]">Verified</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-500 mb-2">
                        {formatLastActive(request.timestamp)}
                      </p>
                      <p className="text-gray-700 bg-gray-50 p-2 rounded-lg my-2">
                        {request.message}
                      </p>
                      
                      <div className="flex space-x-2 mt-3">
                        <Button 
                          className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600"
                          onClick={() => handleAcceptRequest(request.id)}
                        >
                          Accept
                        </Button>
                        <Button 
                          variant="outline" 
                          className="flex-1 border-gray-300"
                          onClick={() => handleDeclineRequest(request.id)}
                        >
                          Decline
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <div className="bg-gray-100 h-20 w-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="h-10 w-10 text-gray-400" />
              </div>
              <h3 className="text-gray-700 font-medium mb-2">No message requests</h3>
              <p className="text-gray-500 text-sm">When someone you don't follow sends you a message, it will appear here</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Messages;
