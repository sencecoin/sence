
import { useGameContext } from "@/context/GameContext";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Trophy, Award, Star, Bookmark, ThumbsUp, Users } from "lucide-react";

const Achievements = () => {
  const { profile } = useGameContext();
  
  // Define available achievements
  const achievements = [
    {
      id: "first_post",
      title: "First Post",
      description: "Create your first content post",
      icon: Bookmark,
      completed: profile.posts.length > 0,
      progress: profile.posts.length > 0 ? 100 : 0,
      reward: 50
    },
    {
      id: "reach_level_5",
      title: "Rising Star",
      description: "Reach level 5",
      icon: Star,
      completed: profile.level >= 5,
      progress: Math.min((profile.level / 5) * 100, 100),
      reward: 200
    },
    {
      id: "get_10_likes",
      title: "Well-Liked",
      description: "Get 10 total likes on your content",
      icon: ThumbsUp,
      completed: profile.posts.reduce((sum, post) => sum + post.likes, 0) >= 10,
      progress: Math.min((profile.posts.reduce((sum, post) => sum + post.likes, 0) / 10) * 100, 100),
      reward: 100
    },
    {
      id: "reach_10_followers",
      title: "Micro-Influencer",
      description: "Reach 10 followers",
      icon: Users,
      completed: profile.followers >= 10,
      progress: Math.min((profile.followers / 10) * 100, 100),
      reward: 150
    },
    {
      id: "create_5_posts",
      title: "Content Creator",
      description: "Create 5 different posts",
      icon: Bookmark,
      completed: profile.posts.length >= 5,
      progress: Math.min((profile.posts.length / 5) * 100, 100),
      reward: 100
    },
    {
      id: "daily_streak_3",
      title: "Consistency is Key",
      description: "Log in for 3 days in a row",
      icon: Award,
      completed: false,
      progress: 33,
      reward: 100
    },
  ];
  
  return (
    <div className="pb-20">
      <div className="bg-blue-500 text-white rounded-xl px-4 py-6 text-center mb-6">
        <Trophy className="h-10 w-10 mx-auto mb-2" />
        <h2 className="text-xl font-bold">Achievements</h2>
        <p className="text-sm opacity-90 mt-1">
          Complete tasks to earn rewards and recognition
        </p>
      </div>
      
      <div className="space-y-3">
        {achievements.map((achievement) => (
          <Card 
            key={achievement.id}
            className={`border ${
              achievement.completed 
                ? "bg-blue-50 border-blue-200" 
                : "border-gray-200"
            }`}
          >
            <div className="p-4">
              <div className="flex items-start">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center mr-3 ${
                  achievement.completed 
                    ? "bg-blue-500 text-white" 
                    : "bg-gray-100 text-gray-400"
                }`}>
                  <achievement.icon className="h-5 w-5" />
                </div>
                
                <div className="flex-1">
                  <h3 className={`font-medium ${
                    achievement.completed ? "text-blue-600" : "text-gray-700"
                  }`}>
                    {achievement.title}
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {achievement.description}
                  </p>
                  
                  <div className="mt-2 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-500">Progress</span>
                      <span className={achievement.completed ? "text-blue-600 font-medium" : "text-gray-500"}>
                        {achievement.progress}%
                      </span>
                    </div>
                    <Progress value={achievement.progress} className="h-1.5" />
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-end mt-2">
                <div className="flex items-center text-yellow-500">
                  <Star className="h-3.5 w-3.5 mr-1 fill-yellow-500" />
                  <span className="text-xs font-medium">
                    {achievement.reward} Stars
                  </span>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Achievements;
