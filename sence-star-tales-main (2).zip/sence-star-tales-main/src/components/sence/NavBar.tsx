
import { Home, User, PlusCircle, MessageSquare, Inbox, Video } from "lucide-react";

interface NavBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const NavBar = ({ activeTab, setActiveTab }: NavBarProps) => {
  const navItems = [
    { id: "feed", icon: Home, label: "Home" },
    { id: "reels", icon: Video, label: "Reels" },
    { id: "create", icon: PlusCircle, label: "Create" },
    { id: "messages", icon: MessageSquare, label: "Chat" },
    { id: "wallet", icon: Inbox, label: "Wallet" },
    { id: "profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 rounded-t-xl shadow-lg z-10">
      <div className="flex justify-around items-center py-2 max-w-md mx-auto overflow-x-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center px-3 py-2 rounded-lg ${
              activeTab === item.id
                ? "text-primary bg-red-50"
                : "text-gray-400 hover:text-primary"
            }`}
          >
            <item.icon size={20} />
            <span className="text-xs mt-1">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default NavBar;
