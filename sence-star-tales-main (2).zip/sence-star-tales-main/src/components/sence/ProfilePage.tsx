import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useGameContext } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { User, Image, Video, Star, Edit, Settings, Coins, UserPlus, Check, Heart, MessageSquare, Plus, Calendar, Award, BookmarkCheck } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";

const ProfileStory = ({ isAddButton = false, image = null, username = "", seen = false }) => {
  return (
    <div className="story-button mx-1.5 w-20">
      {isAddButton ? (
        <div className="rounded-full border-2 border-dashed border-gray-300 h-16 w-16 flex items-center justify-center mb-1">
          <Plus className="h-6 w-6 text-gray-400" />
        </div>
      ) : (
        <div className={`${seen ? "border-2 border-gray-200" : "story-ring"}`}>
          {image ? (
            <img src={image} alt={username} className="h-16 w-16 object-cover" />
          ) : (
            <div className="avatar h-16 w-16 bg-gray-100 flex items-center justify-center">
              <User className="h-6 w-6 text-gray-400" />
            </div>
          )}
        </div>
      )}
      <span className="text-xs mt-1 truncate w-full text-center">
        {isAddButton ? "New" : username || "Story"}
      </span>
    </div>
  );
};

const ProfileHighlight = ({ title = "", image = null, isAdd = false }) => {
  return (
    <div className="highlight-item w-20">
      {isAdd ? (
        <div className="rounded-full border-2 border-dashed border-gray-300 h-16 w-16 flex items-center justify-center mb-1">
          <Plus className="h-6 w-6 text-gray-400" />
        </div>
      ) : (
        <div className="rounded-full border-2 border-gray-200 h-16 w-16 overflow-hidden mb-1">
          {image ? (
            <img src={image} alt={title} className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-gray-100 flex items-center justify-center">
              <Award className="h-6 w-6 text-gray-400" />
            </div>
          )}
        </div>
      )}
      <span className="text-xs truncate w-full text-center">
        {isAdd ? "New" : title}
      </span>
    </div>
  );
};

const PostPreview = ({ post, onClick }) => {
  const isPhoto = post.type === "photo";
  
  return (
    <div 
      className="aspect-square bg-gray-100 rounded-md flex items-center justify-center relative overflow-hidden group cursor-pointer"
      onClick={() => onClick(post)}
    >
      {isPhoto ? (
        post.imageUrl ? (
          <img 
            src={post.imageUrl} 
            alt={post.caption} 
            className="h-full w-full object-cover"
          />
        ) : (
          <Image className="h-6 w-6 text-gray-400" />
        )
      ) : (
        post.videoUrl ? (
          <video
            src={post.videoUrl}
            className="h-full w-full object-cover"
          />
        ) : (
          <Video className="h-6 w-6 text-gray-400" />
        )
      )}
      <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <div className="flex items-center space-x-3 text-white">
          <div className="flex items-center">
            <Heart className="h-4 w-4 mr-1" />
            <span>{post.likes}</span>
          </div>
          <div className="flex items-center">
            <MessageSquare className="h-4 w-4 mr-1" />
            <span>{post.comments.length}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const PostDetailDialog = ({ post, isOpen, onClose, currentUser, handleLike, handleAddComment }) => {
  const [commentText, setCommentText] = useState("");
  const [selectedEmoji, setSelectedEmoji] = useState("👍");
  const { users } = useGameContext();
  const emojis = ["👍", "❤️", "😂", "🔥", "👏", "🎉"];
  
  if (!post) return null;
  
  const postCreator = users.find(user => user.id === post.userId);
  const isLiked = post.likedBy?.includes(currentUser?.id);
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-hidden p-0">
        <DialogTitle className="sr-only">Post Details</DialogTitle>
        <div className="grid sm:grid-cols-2 h-full">
          <div className="bg-black flex items-center justify-center h-80 sm:h-auto">
            {post.type === "photo" ? (
              post.imageUrl ? (
                <img 
                  src={post.imageUrl}
                  alt={post.caption}
                  className="max-h-full max-w-full object-contain"
                />
              ) : (
                <Image className="h-12 w-12 text-gray-600" />
              )
            ) : (
              post.videoUrl ? (
                <video
                  src={post.videoUrl}
                  controls
                  className="max-h-full max-w-full"
                />
              ) : (
                <Video className="h-12 w-12 text-gray-600" />
              )
            )}
          </div>
          
          <div className="flex flex-col">
            <div className="p-4 border-b">
              <div className="flex items-center">
                <Avatar className="h-8 w-8 mr-3">
                  {postCreator?.profileImage ? (
                    <img src={postCreator.profileImage} alt={postCreator.username} className="h-full w-full object-cover" />
                  ) : (
                    <div className="bg-gradient-to-br from-red-500 via-purple-500 to-blue-500 text-white flex items-center justify-center h-full w-full rounded-full">
                      {postCreator ? postCreator.username.charAt(0).toUpperCase() : post.caption.charAt(0).toUpperCase()}
                    </div>
                  )}
                </Avatar>
                <div>
                  <p className="font-medium text-sm">{postCreator?.username || "User"}</p>
                  <p className="text-xs text-gray-500">{post.topic}</p>
                </div>
              </div>
            </div>
            
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                <p className="text-sm">{post.caption}</p>
                
                <div className="flex flex-wrap gap-2">
                  {post.hashtags.map((tag, idx) => (
                    <span key={idx} className="text-xs text-blue-600">
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="pt-4">
                  <h4 className="font-medium text-sm mb-2">Comments</h4>
                  {post.comments.length > 0 ? (
                    <div className="space-y-2">
                      {post.comments.map((comment, idx) => (
                        <div key={idx} className="text-sm">
                          <span className="font-medium mr-2">{comment.username}</span>
                          <span>{comment.text} {comment.emoji}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">No comments yet</p>
                  )}
                </div>
              </div>
            </ScrollArea>
            
            <div className="p-4 border-t mt-auto">
              <div className="flex mb-2">
                <button 
                  onClick={() => handleLike(post.id)}
                  className="mr-4"
                >
                  <Heart className={`h-6 w-6 ${isLiked ? 'fill-red-500 stroke-red-500' : 'text-gray-700'}`} />
                </button>
                <MessageSquare className="h-6 w-6 text-gray-700 mr-4" />
              </div>
              <p className="font-medium text-sm mb-2">{post.likes} likes</p>
              
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Add a comment..."
                  className="flex-1 text-sm border rounded-full px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
                />
                <select 
                  className="border rounded-full px-2 py-1.5 text-sm"
                  value={selectedEmoji}
                  onChange={(e) => setSelectedEmoji(e.target.value)}
                >
                  {emojis.map((emoji) => (
                    <option key={emoji} value={emoji}>{emoji}</option>
                  ))}
                </select>
                <Button 
                  onClick={() => {
                    if (commentText.trim()) {
                      handleAddComment(post.id, commentText, selectedEmoji);
                      setCommentText("");
                    }
                  }}
                  size="sm" 
                  className="rounded-full"
                >
                  Post
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

const ProfilePage = () => {
  const navigate = useNavigate();
  const { profile, currentUser, users, followUser, unfollowUser, feedPosts, likePost, addComment } = useGameContext();
  const { toast } = useToast();
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedPost, setSelectedPost] = useState(null);
  const [isPostDialogOpen, setIsPostDialogOpen] = useState(false);
  
  const viewingUser = viewingUserId ? users.find(user => user.id === viewingUserId) : null;
  const profileData = viewingUser || currentUser || profile;
  
  const userPosts = feedPosts.filter(post => post.userId === (viewingUserId || currentUser?.id));
  
  const totalLikes = userPosts.reduce((sum, post) => sum + post.likes, 0);
  
  const isFollowing = currentUser && viewingUserId ? 
    currentUser.following.includes(viewingUserId) : false;
  
  const handleFollowToggle = () => {
    if (!currentUser || !viewingUserId) return;
    
    if (isFollowing) {
      unfollowUser(viewingUserId);
      toast({
        title: "Unfollowed",
        description: `You unfollowed ${viewingUser?.username}`,
      });
    } else {
      followUser(viewingUserId);
      toast({
        title: "Following",
        description: `You are now following ${viewingUser?.username}`,
      });
    }
  };
  
  const handleUserSelect = (userId: string) => {
    setViewingUserId(userId === viewingUserId ? null : userId);
  };

  const handleStartChat = (userId: string) => {
    navigate(`/chat/${userId}`);
  };

  const triggerStoryUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleStoryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      toast({
        title: "Story Added",
        description: "Your story has been uploaded successfully",
      });
      // In a real app, you would upload this to a server
    }
  };
  
  const handlePostClick = (post) => {
    setSelectedPost(post);
    setIsPostDialogOpen(true);
  };
  
  const handleClosePostDialog = () => {
    setIsPostDialogOpen(false);
    setTimeout(() => setSelectedPost(null), 300);
  };
  
  const handleLikePost = (postId: string) => {
    if (!currentUser) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to like posts",
        variant: "destructive"
      });
      return;
    }
    
    likePost(postId);
    
    toast({
      title: "Post liked!",
      description: "You've liked this post"
    });
  };
  
  const handleAddComment = (postId: string, text: string, emoji: string) => {
    if (!currentUser) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to comment",
        variant: "destructive"
      });
      return;
    }
    
    addComment(postId, text, emoji);
    
    toast({
      title: "Comment added!",
      description: "Your comment has been added to the post"
    });
  };
  
  return (
    <div className="pb-24">
      <ScrollArea className="w-full mb-5">
        <div className="flex py-4">
          {viewingUserId ? (
            <>
              <ProfileStory username={viewingUser?.username} image={viewingUser?.profileImage || undefined} />
              <ProfileStory username="user2" seen={true} />
              <ProfileStory username="user3" />
            </>
          ) : (
            <>
              <ProfileStory isAddButton={true} />
              <ProfileStory username="Your story" image={currentUser?.profileImage || undefined} />
              <ProfileStory username="user1" seen={true} />
              <ProfileStory username="user2" />
              <ProfileStory username="user3" />
              <ProfileStory username="user4" seen={true} />
            </>
          )}

          <input 
            type="file" 
            ref={fileInputRef}
            className="hidden" 
            accept="image/*,video/*" 
            onChange={handleStoryUpload} 
          />
        </div>
      </ScrollArea>

      <div className="phantom-card mb-5 animate-fade-in">
        <div className="flex flex-col items-center">
          <div className="h-20 w-20 instagram-gradient rounded-full flex items-center justify-center mb-3 p-0.5">
            <div className="h-full w-full bg-white rounded-full flex items-center justify-center overflow-hidden">
              {profileData && 'profileImage' in profileData && profileData.profileImage ? (
                <img 
                  src={profileData.profileImage} 
                  alt={profileData.username}
                  className="h-full w-full object-cover" 
                />
              ) : (
                <User className="h-10 w-10 text-primary" />
              )}
            </div>
          </div>
          <div className="flex items-center">
            <h2 className="text-xl font-bold text-gray-800">{profileData.username}</h2>
            {profileData.isVerified && (
              <Badge variant="outline" className="ml-1 h-5 bg-blue-500 text-white px-1 text-xs rounded-sm">
                ✓
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-1 text-sm text-gray-500">
            <Star className="h-4 w-4 text-secondary" />
            <span>Level {profileData.level} Creator</span>
          </div>
          
          <p className="text-gray-600 text-center mt-2">
            {profileData.bio || "No bio yet."}
          </p>
          
          {viewingUserId ? (
            <div className="flex space-x-2 mt-3">
              <Button 
                variant={isFollowing ? "outline" : "default"}
                size="sm" 
                className={`${isFollowing ? 'border-gray-300 text-gray-700' : 'bg-primary hover:bg-primary/90 text-white'} rounded-full`}
                onClick={handleFollowToggle}
              >
                {isFollowing ? (
                  <>
                    <Check className="h-3.5 w-3.5 mr-1" /> Following
                  </>
                ) : (
                  <>
                    <UserPlus className="h-3.5 w-3.5 mr-1" /> Follow
                  </>
                )}
              </Button>
              
              <Button 
                variant="default" 
                size="sm" 
                className="bg-primary hover:bg-primary/90 rounded-full" 
                onClick={() => handleStartChat(viewingUserId)}
              >
                <MessageSquare className="h-3.5 w-3.5 mr-1" /> Message
              </Button>
            </div>
          ) : (
            <div className="flex space-x-2 mt-3">
              <Button 
                variant="outline" 
                size="sm" 
                className="text-gray-800 border-gray-300 hover:bg-gray-50 rounded-full"
                onClick={() => navigate("/profile/edit")}
              >
                <Edit className="h-3.5 w-3.5 mr-1" />
                Edit Profile
              </Button>
              <Button variant="outline" size="sm" className="border-gray-300 rounded-full">
                <Settings className="h-3.5 w-3.5" />
              </Button>
            </div>
          )}
          
          <div className="flex justify-center w-full mt-6 border-t border-b py-3 border-gray-100">
            <div className="text-center px-6">
              <div className="font-bold text-gray-800">{userPosts.length}</div>
              <div className="text-xs text-gray-500">Posts</div>
            </div>
            <div
              className="text-center px-6 border-x border-gray-100"
            >
              <div className="font-bold text-gray-800">{profileData.followers}</div>
              <div className="text-xs text-gray-500">Followers</div>
            </div>
            <div
              className="text-center px-6"
            >
              <div className="font-bold text-gray-800">{profileData.followingCount}</div>
              <div className="text-xs text-gray-500">Following</div>
            </div>
          </div>
          
          <div className="mt-3 w-full">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <div className="text-accent">
                  <span role="img" aria-label="heart">❤️</span>
                </div>
                <div>
                  <div className="text-sm font-medium">{totalLikes} Total Likes</div>
                  <div className="text-xs text-gray-500">{profileData.stars} Coins earned</div>
                </div>
              </div>
              <Button variant="default" size="sm" className="bg-accent hover:bg-accent/90 rounded-full">
                <Coins className="h-3.5 w-3.5 mr-1" />
                View Stats
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="phantom-card mb-5">
        <h3 className="font-medium text-gray-700 mb-3">Highlights</h3>
        <div className="highlight-container">
          {!viewingUserId && (
            <ProfileHighlight isAdd={true} />
          )}
          <ProfileHighlight title="Travel" />
          <ProfileHighlight title="Food" />
          <ProfileHighlight title="Fitness" />
          <ProfileHighlight title="Music" />
          <ProfileHighlight title="Art" />
        </div>
      </div>
      
      <Tabs defaultValue="posts" className="w-full">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="videos">Videos</TabsTrigger>
          <TabsTrigger value="reels">Reels</TabsTrigger>
          <TabsTrigger value="saved">Saved</TabsTrigger>
        </TabsList>
        
        <TabsContent value="posts" className="mt-0">
          {userPosts.filter(post => post.type === "photo").length > 0 ? (
            <div className="grid grid-cols-3 gap-1">
              {userPosts.filter(post => post.type === "photo").map(post => (
                <PostPreview key={post.id} post={post} onClick={handlePostClick} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-10">
                <p className="text-gray-500">No photo posts yet</p>
                <Button 
                  variant="outline" 
                  className="mt-3"
                  onClick={() => navigate("/create")}
                >
                  <Plus className="h-4 w-4 mr-1" /> Create Your First Post
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="videos" className="mt-0">
          {userPosts.filter(post => post.type === "video").length > 0 ? (
            <div className="grid grid-cols-3 gap-1">
              {userPosts.filter(post => post.type === "video").map(post => (
                <PostPreview key={post.id} post={post} onClick={handlePostClick} />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-10">
                <p className="text-gray-500">No video posts yet</p>
                <Button 
                  variant="outline" 
                  className="mt-3"
                  onClick={() => navigate("/create")}
                >
                  <Plus className="h-4 w-4 mr-1" /> Create Your First Video
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="reels" className="mt-0">
          <Card>
            <CardContent className="text-center py-10">
              <p className="text-gray-500">No reels yet</p>
              <Button 
                variant="outline" 
                className="mt-3"
                onClick={() => navigate("/create")}
              >
                <Plus className="h-4 w-4 mr-1" /> Create Your First Reel
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="saved" className="mt-0">
          <Card>
            <CardContent className="text-center py-10">
              <p className="text-gray-500">No saved posts</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-6">
        <h3 className="font-medium text-gray-700 mb-3">Suggested for you</h3>
        <div className="space-y-2">
          {users
            .filter(user => user.id !== currentUser?.id && (!currentUser?.following.includes(user.id)))
            .slice(0, 3)
            .map(user => (
              <div key={user.id} className="phantom-card flex items-center justify-between">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10">
                    {'profileImage' in user && user.profileImage ? (
                      <img
                        src={user.profileImage}
                        alt={user.username}
                        className="h-full w-full object-cover rounded-full"
                      />
                    ) : (
                      <div className="bg-accent text-white flex items-center justify-center h-full w-full rounded-full">
                        {user.username.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </Avatar>
                  <div className="ml-3">
                    <div className="flex items-center">
                      <p className="font-medium text-gray-800">{user.username}</p>
                      {user.isVerified && (
                        <Badge variant="outline" className="ml-1 h-4 bg-blue-500 text-white px-1 text-[8px] rounded-sm">
                          ✓
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-500">{user.followers} followers</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-sm h-8 rounded-full"
                    onClick={() => handleUserSelect(user.id)}
                  >
                    View
                  </Button>
                  <Button
                    variant="default"
                    size="sm"
                    className="bg-primary hover:bg-primary/90 text-white text-sm h-8 rounded-full"
                    onClick={() => handleStartChat(user.id)}
                  >
                    Message
                  </Button>
                </div>
              </div>
            ))}
        </div>
      </div>
      
      <PostDetailDialog
        post={selectedPost}
        isOpen={isPostDialogOpen}
        onClose={handleClosePostDialog}
        currentUser={currentUser}
        handleLike={handleLikePost}
        handleAddComment={handleAddComment}
      />
    </div>
  );
};

export default ProfilePage;
