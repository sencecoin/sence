
import { useGameContext } from "@/context/GameContext";
import { Inbox, TrendingUp, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

const Dashboard = () => {
  const { profile, collectDailyBonus, calculateLevel } = useGameContext();
  
  // Calculate progress to next level
  const currentLevelFame = (profile.level - 1) * 100;
  const nextLevelFame = profile.level * 100;
  const progressToNextLevel = ((profile.fame - currentLevelFame) / 100) * 100;
  
  return (
    <div className="space-y-6 pb-20">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100">
          <div className="flex items-center mb-1">
            <Inbox className="text-yellow-500 mr-2" size={16} />
            <h3 className="text-sm font-medium text-gray-700">Coins</h3>
          </div>
          <p className="text-xl font-bold text-blue-600">{profile.stars}</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100">
          <div className="flex items-center mb-1">
            <TrendingUp className="text-green-500 mr-2" size={16} />
            <h3 className="text-sm font-medium text-gray-700">Fame</h3>
          </div>
          <p className="text-xl font-bold text-blue-600">{profile.fame}</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100">
          <div className="flex items-center mb-1">
            <Users className="text-purple-500 mr-2" size={16} />
            <h3 className="text-sm font-medium text-gray-700">Followers</h3>
          </div>
          <p className="text-xl font-bold text-blue-600">{profile.followers}</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100">
          <div className="flex items-center mb-1">
            <Star className="text-blue-500 mr-2" size={16} />
            <h3 className="text-sm font-medium text-gray-700">Level</h3>
          </div>
          <p className="text-xl font-bold text-blue-600">{profile.level}</p>
        </div>
      </div>
      
      {/* Level Progress */}
      <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-sm font-medium text-gray-700">Level Progress</h3>
          <span className="text-xs text-gray-500">
            {profile.fame % 100}/100 Fame
          </span>
        </div>
        <Progress value={progressToNextLevel} className="h-2" />
        <p className="text-xs text-gray-500 mt-2">
          {100 - (profile.fame % 100)} more Fame needed for level {profile.level + 1}
        </p>
      </div>
      
      {/* Daily Bonus */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl shadow-md p-4 text-white">
        <h3 className="text-lg font-semibold mb-2 flex items-center">
          <Star className="mr-2" size={18} />
          Daily Bonus
        </h3>
        <p className="text-sm mb-3">
          {profile.dailyBonus 
            ? "Collect your 50 Coins daily bonus!" 
            : "You've already collected your bonus today. Come back tomorrow!"}
        </p>
        <Button 
          onClick={collectDailyBonus}
          disabled={!profile.dailyBonus}
          variant="secondary" 
          className="w-full bg-white text-blue-600 hover:bg-blue-50"
        >
          {profile.dailyBonus ? "Collect 50 Coins" : "Come Back Tomorrow"}
        </Button>
      </div>
      
      {/* Latest Stats */}
      <div className="bg-white rounded-xl shadow-sm p-4 border border-blue-100">
        <h3 className="text-sm font-medium text-gray-700 mb-3">Your Stats</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Total Posts</span>
            <span className="text-sm font-medium">{profile.posts.length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Total Likes</span>
            <span className="text-sm font-medium">
              {profile.posts.reduce((sum, post) => sum + post.likes, 0)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Total Views</span>
            <span className="text-sm font-medium">
              {profile.posts.reduce((sum, post) => sum + post.views, 0)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
