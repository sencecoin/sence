
import { useState, useRef, useEffect } from "react";
import { useGameContext } from "@/context/GameContext";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  Heart,
  MessageSquare,
  Share2, 
  Image, 
  Video, 
  User,
  BookmarkPlus,
  MoreHorizontal,
  Plus,
  RefreshCw
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

const Feed = () => {
  const { feedPosts, likePost, addComment, currentUser, users } = useGameContext();
  const [commentText, setCommentText] = useState("");
  const [activeCommentPost, setActiveCommentPost] = useState<string | null>(null);
  const [selectedEmoji, setSelectedEmoji] = useState("👍");
  const [selectedPost, setSelectedPost] = useState(null);
  const [isPostDialogOpen, setIsPostDialogOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const commentInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  const emojis = ["👍", "❤️", "😂", "🔥", "👏", "🎉"];
  
  // Pull to refresh implementation
  useEffect(() => {
    if (refreshing) {
      const timer = setTimeout(() => {
        setRefreshing(false);
        toast({
          description: "Feed refreshed"
        });
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [refreshing, toast]);

  const handleRefresh = () => {
    setRefreshing(true);
  };
  
  const handleLike = (postId: string) => {
    if (!currentUser) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to like posts",
        variant: "destructive"
      });
      return;
    }
    
    likePost(postId);
    
    toast({
      title: "Post liked!",
      description: "You've liked this post"
    });
  };
  
  const toggleCommentSection = (postId: string) => {
    if (activeCommentPost === postId) {
      setActiveCommentPost(null);
    } else {
      setActiveCommentPost(postId);
      setTimeout(() => {
        commentInputRef.current?.focus();
      }, 100);
    }
  };
  
  const handleAddComment = (postId: string) => {
    if (!currentUser) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to comment",
        variant: "destructive"
      });
      return;
    }
    
    if (!commentText.trim()) {
      toast({
        description: "Comment cannot be empty",
        variant: "destructive"
      });
      return;
    }
    
    addComment(postId, commentText, selectedEmoji);
    setCommentText("");
    
    toast({
      title: "Comment added!",
      description: "Your comment has been added to the post"
    });
  };
  
  const handleShare = (postId: string) => {
    toast({
      title: "Shared!",
      description: "Post has been shared"
    });
  };
  
  const getPostCreator = (userId: string) => {
    return users.find(user => user.id === userId);
  };
  
  const isPostLikedByUser = (postId: string) => {
    if (!currentUser) return false;
    
    const post = feedPosts.find(post => post.id === postId);
    return post ? post.likedBy.includes(currentUser.id) : false;
  };

  const handlePostClick = (post) => {
    setSelectedPost(post);
    setIsPostDialogOpen(true);
  };
  
  const handleClosePostDialog = () => {
    setIsPostDialogOpen(false);
    setTimeout(() => setSelectedPost(null), 300);
  };
  
  if (feedPosts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <p className="text-gray-500 mb-4">No posts yet</p>
        <Button variant="outline" className="bg-white">Create your first post</Button>
      </div>
    );
  }
  
  return (
    <div className="pb-20 space-y-5">
      {/* Refresh indicator */}
      {refreshing && (
        <div className="flex justify-center py-3">
          <RefreshCw className="animate-spin h-5 w-5 text-primary" />
        </div>
      )}

      {/* Stories section with iOS-style UI */}
      <div className="bg-white dark:bg-card rounded-2xl p-4 overflow-hidden shadow-sm border border-gray-100 dark:border-gray-800">
        <div className="highlight-container">
          {/* Add your own story */}
          <div className="story-button">
            <div className="h-16 w-16 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center bg-gray-50 dark:bg-gray-800 dark:border-gray-700">
              <Plus className="h-6 w-6 text-gray-400" />
            </div>
            <span className="text-xs mt-1 font-medium">Your Story</span>
          </div>
          
          {/* User stories */}
          {users.map((user) => (
            <div key={user.id} className="story-button">
              <div className="story-ring">
                <Avatar className="h-16 w-16">
                  {user.profileImage ? (
                    <img src={user.profileImage} alt={user.username} className="h-full w-full object-cover" />
                  ) : (
                    <div className="bg-gradient-to-br from-red-500 via-purple-500 to-blue-500 flex items-center justify-center h-full w-full text-white text-lg font-bold">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                  )}
                </Avatar>
              </div>
              <span className="text-xs mt-1 font-medium">{user.username}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Button to refresh feed */}
      <div className="flex justify-center">
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs rounded-full"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`h-3 w-3 mr-1 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh Feed
        </Button>
      </div>
      
      {/* Posts feed */}
      {feedPosts.map((post) => {
        const postCreator = getPostCreator(post.userId);
        const isLiked = isPostLikedByUser(post.id);
        
        return (
          <Card key={post.id} className="overflow-hidden bg-white dark:bg-card rounded-2xl border-none shadow-sm animate-fade-in">
            <CardHeader className="p-3 pb-2">
              <div className="flex justify-between items-center">
                <Link to={`/profile/${post.userId}`} className="flex items-center space-x-2">
                  <Avatar className="h-9 w-9 ring-2 ring-offset-2 ring-gray-100 dark:ring-gray-800">
                    {postCreator?.profileImage ? (
                      <img src={postCreator.profileImage} alt={postCreator.username} className="h-full w-full object-cover" />
                    ) : (
                      <div className="bg-gradient-to-br from-red-500 via-purple-500 to-blue-500 text-white flex items-center justify-center h-full w-full rounded-full">
                        {postCreator ? postCreator.username.charAt(0).toUpperCase() : post.caption.charAt(0).toUpperCase()}
                      </div>
                    )}
                  </Avatar>
                  <div>
                    <p className="text-sm font-semibold flex items-center">
                      {postCreator ? postCreator.username : "Creator"}
                      {postCreator?.isVerified && (
                        <Badge variant="outline" className="ml-1 h-4 bg-blue-500 text-white px-1 text-[8px] rounded-sm">
                          ✓
                        </Badge>
                      )}
                    </p>
                    <p className="text-xs text-gray-500">
                      {post.topic} • {new Date(post.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </p>
                  </div>
                </Link>
                <button className="text-gray-500 p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
                  <MoreHorizontal className="h-5 w-5" />
                </button>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              <div 
                className="aspect-square bg-gray-50 dark:bg-gray-900 flex items-center justify-center relative overflow-hidden cursor-pointer"
                onClick={() => handlePostClick(post)}
              >
                {post.type === "photo" ? (
                  post.imageUrl ? (
                    <img 
                      src={post.imageUrl} 
                      alt={post.caption} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Image className="h-14 w-14 text-gray-300" />
                  )
                ) : (
                  post.videoUrl ? (
                    <video
                      src={post.videoUrl}
                      className="w-full h-full object-cover"
                      controls
                    />
                  ) : (
                    <Video className="h-14 w-14 text-gray-300" />
                  )
                )}
              </div>
              
              {/* Action buttons - iOS style */}
              <div className="px-4 pt-3 flex justify-between">
                <div className="flex space-x-4">
                  <button 
                    onClick={() => handleLike(post.id)}
                    className="focus:outline-none transform active:scale-125 transition-transform"
                  >
                    <Heart className={`h-6 w-6 ${isLiked ? 'fill-red-500 stroke-red-500' : 'text-gray-700 dark:text-gray-300'}`} />
                  </button>
                  <button 
                    onClick={() => toggleCommentSection(post.id)}
                    className="focus:outline-none transform active:scale-125 transition-transform"
                  >
                    <MessageSquare className="h-6 w-6 text-gray-700 dark:text-gray-300" />
                  </button>
                  <button 
                    onClick={() => handleShare(post.id)}
                    className="focus:outline-none transform active:scale-125 transition-transform"
                  >
                    <Share2 className="h-6 w-6 text-gray-700 dark:text-gray-300" />
                  </button>
                </div>
                <button className="focus:outline-none transform active:scale-125 transition-transform">
                  <BookmarkPlus className="h-6 w-6 text-gray-700 dark:text-gray-300" />
                </button>
              </div>
              
              {/* Likes count */}
              <div className="px-4 pt-2">
                <p className="text-sm font-semibold">{post.likes} likes</p>
              </div>
              
              {/* Caption */}
              <div className="px-4 pt-1">
                <p className="text-sm">
                  <span className="font-semibold">{postCreator ? postCreator.username : "Creator"}</span>{" "}
                  {post.caption}
                </p>
                <div className="flex gap-1 flex-wrap mt-1">
                  {post.hashtags.map((tag, index) => (
                    <span key={index} className="text-accent text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              
              {/* Comments section */}
              {post.comments.length > 0 && (
                <div className="px-4 pt-1">
                  <p className="text-sm text-gray-500">
                    View all {post.comments.length} comments
                  </p>
                  <div className="mt-1">
                    {post.comments.slice(0, 2).map((comment, index) => (
                      <div key={index} className="flex text-sm mt-1">
                        <span className="font-semibold mr-2">{comment.username}</span>
                        <span>{comment.text} {comment.emoji}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Active comment section */}
              {activeCommentPost === post.id && (
                <div className="px-4 pt-2 pb-3 border-t mt-2 border-gray-100 dark:border-gray-800">
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      ref={commentInputRef}
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Add a comment..."
                      className="flex-1 text-sm border rounded-full px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400 dark:bg-gray-800 dark:border-gray-700"
                    />
                    <select 
                      className="border rounded-full px-2 py-1.5 text-sm bg-white dark:bg-gray-800 dark:border-gray-700"
                      value={selectedEmoji}
                      onChange={(e) => setSelectedEmoji(e.target.value)}
                    >
                      {emojis.map((emoji) => (
                        <option key={emoji} value={emoji}>{emoji}</option>
                      ))}
                    </select>
                    <Button 
                      onClick={() => handleAddComment(post.id)} 
                      size="sm" 
                      className="rounded-full bg-blue-500 hover:bg-blue-600"
                    >
                      Post
                    </Button>
                  </div>
                </div>
              )}
              
              {/* Timestamp */}
              <div className="px-4 pt-1 pb-4">
                <p className="text-xs text-gray-400">
                  {new Date(post.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                </p>
              </div>
            </CardContent>
          </Card>
        );
      })}

      {/* Post Detail Dialog */}
      <Dialog open={isPostDialogOpen} onOpenChange={handleClosePostDialog}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-hidden p-0">
          <DialogTitle className="sr-only">Post Details</DialogTitle>
          {selectedPost && (
            <div className="grid sm:grid-cols-2 h-full">
              <div className="bg-black flex items-center justify-center h-80 sm:h-auto">
                {selectedPost.type === "photo" ? (
                  selectedPost.imageUrl ? (
                    <img 
                      src={selectedPost.imageUrl}
                      alt={selectedPost.caption}
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <Image className="h-12 w-12 text-gray-600" />
                  )
                ) : (
                  selectedPost.videoUrl ? (
                    <video
                      src={selectedPost.videoUrl}
                      controls
                      className="max-h-full max-w-full"
                    />
                  ) : (
                    <Video className="h-12 w-12 text-gray-600" />
                  )
                )}
              </div>
              
              <div className="flex flex-col">
                <div className="p-4 border-b">
                  <div className="flex items-center">
                    <Avatar className="h-8 w-8 mr-3">
                      {getPostCreator(selectedPost.userId)?.profileImage ? (
                        <img 
                          src={getPostCreator(selectedPost.userId).profileImage} 
                          alt={getPostCreator(selectedPost.userId).username} 
                          className="h-full w-full object-cover" 
                        />
                      ) : (
                        <div className="bg-gradient-to-br from-red-500 via-purple-500 to-blue-500 text-white flex items-center justify-center h-full w-full rounded-full">
                          {getPostCreator(selectedPost.userId) ? 
                            getPostCreator(selectedPost.userId).username.charAt(0).toUpperCase() : 
                            selectedPost.caption.charAt(0).toUpperCase()}
                        </div>
                      )}
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{getPostCreator(selectedPost.userId)?.username || "User"}</p>
                      <p className="text-xs text-gray-500">{selectedPost.topic}</p>
                    </div>
                  </div>
                </div>
                
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    <p className="text-sm">{selectedPost.caption}</p>
                    
                    <div className="flex flex-wrap gap-2">
                      {selectedPost.hashtags.map((tag, idx) => (
                        <span key={idx} className="text-xs text-blue-600">
                          {tag}
                        </span>
                      ))}
                    </div>
                    
                    <div className="pt-4">
                      <h4 className="font-medium text-sm mb-2">Comments</h4>
                      {selectedPost.comments.length > 0 ? (
                        <div className="space-y-2">
                          {selectedPost.comments.map((comment, idx) => (
                            <div key={idx} className="text-sm">
                              <span className="font-medium mr-2">{comment.username}</span>
                              <span>{comment.text} {comment.emoji}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-gray-500">No comments yet</p>
                      )}
                    </div>
                  </div>
                </ScrollArea>
                
                <div className="p-4 border-t mt-auto">
                  <div className="flex mb-2">
                    <button 
                      onClick={() => handleLike(selectedPost.id)}
                      className="mr-4"
                    >
                      <Heart className={`h-6 w-6 ${
                        isPostLikedByUser(selectedPost.id) ? 
                          'fill-red-500 stroke-red-500' : 
                          'text-gray-700'
                      }`} />
                    </button>
                    <MessageSquare className="h-6 w-6 text-gray-700 mr-4" />
                    <Share2 className="h-6 w-6 text-gray-700" />
                  </div>
                  <p className="font-medium text-sm mb-2">{selectedPost.likes} likes</p>
                  
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Add a comment..."
                      className="flex-1 text-sm border rounded-full px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-400"
                    />
                    <select 
                      className="border rounded-full px-2 py-1.5 text-sm"
                      value={selectedEmoji}
                      onChange={(e) => setSelectedEmoji(e.target.value)}
                    >
                      {emojis.map((emoji) => (
                        <option key={emoji} value={emoji}>{emoji}</option>
                      ))}
                    </select>
                    <Button 
                      onClick={() => {
                        handleAddComment(selectedPost.id);
                      }}
                      size="sm" 
                      className="rounded-full"
                    >
                      Post
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Feed;
