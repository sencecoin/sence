
import React from 'react';
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Globe, Lock, Users, User } from "lucide-react";

interface AudienceSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

const AudienceSelector: React.FC<AudienceSelectorProps> = ({ value, onChange }) => {
  return (
    <RadioGroup value={value} onValueChange={onChange} className="space-y-2">
      <div className="flex items-center space-x-2 rounded-md border p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" onClick={() => onChange("public")}>
        <RadioGroupItem value="public" id="public" />
        <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mr-2">
          <Globe className="h-4 w-4 text-blue-600 dark:text-blue-400" />
        </div>
        <div>
          <Label htmlFor="public" className="font-medium">Public</Label>
          <p className="text-xs text-gray-500">Anyone can see this post</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 rounded-md border p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" onClick={() => onChange("followers")}>
        <RadioGroupItem value="followers" id="followers" />
        <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center mr-2">
          <Users className="h-4 w-4 text-green-600 dark:text-green-400" />
        </div>
        <div>
          <Label htmlFor="followers" className="font-medium">Followers only</Label>
          <p className="text-xs text-gray-500">Only your followers can see this post</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 rounded-md border p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" onClick={() => onChange("close")}>
        <RadioGroupItem value="close" id="close" />
        <div className="h-8 w-8 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center mr-2">
          <User className="h-4 w-4 text-purple-600 dark:text-purple-400" />
        </div>
        <div>
          <Label htmlFor="close" className="font-medium">Close Friends</Label>
          <p className="text-xs text-gray-500">Only your close friends can see this post</p>
        </div>
      </div>
      
      <div className="flex items-center space-x-2 rounded-md border p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" onClick={() => onChange("private")}>
        <RadioGroupItem value="private" id="private" />
        <div className="h-8 w-8 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center mr-2">
          <Lock className="h-4 w-4 text-red-600 dark:text-red-400" />
        </div>
        <div>
          <Label htmlFor="private" className="font-medium">Private</Label>
          <p className="text-xs text-gray-500">Only you can see this post</p>
        </div>
      </div>
    </RadioGroup>
  );
};

export default AudienceSelector;
