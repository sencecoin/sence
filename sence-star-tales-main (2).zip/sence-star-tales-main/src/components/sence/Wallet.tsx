
import { useState } from "react";
import { useGameContext } from "@/context/GameContext";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Inbox, User, Send, Clock, Download, Wallet as WalletIcon, ArrowDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const Wallet = () => {
  const { profile, addStars } = useGameContext();
  const [amount, setAmount] = useState("");
  const [recipient, setRecipient] = useState("");
  const [activeTab, setActiveTab] = useState<"balance" | "transactions" | "withdraw">("balance");
  
  // Mock transaction history
  const transactions = [
    { id: 1, type: "receive", amount: 50, from: "System", date: new Date(Date.now() - 86400000), note: "Daily Bonus" },
    { id: 2, type: "send", amount: 25, to: "User123", date: new Date(Date.now() - 172800000), note: "Payment" },
    { id: 3, type: "receive", amount: 15, from: "Fan452", date: new Date(Date.now() - 259200000), note: "Tip" },
  ];
  
  const handleSend = () => {
    const amountNumber = Number(amount);
    if (amountNumber <= 0 || amountNumber > profile.stars || !recipient) {
      return;
    }
    
    // Add the send transaction logic using GameContext
    addStars(-amountNumber);
    setAmount("");
    setRecipient("");
  };
  
  return (
    <div className="pb-20">
      <div className="bg-gradient-to-r from-primary to-accent rounded-xl shadow-md p-6 mb-5 text-white">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-sm font-medium">Your Balance</h3>
          <WalletIcon size={20} />
        </div>
        <p className="text-3xl font-bold mb-1">{profile.stars} Coins</p>
        <p className="text-sm opacity-80">Level {profile.level} Creator</p>
      </div>
      
      <Tabs defaultValue="balance" onValueChange={(v) => setActiveTab(v as "balance" | "transactions" | "withdraw")}>
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="balance">Wallet</TabsTrigger>
          <TabsTrigger value="transactions">History</TabsTrigger>
          <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
        </TabsList>
        
        <TabsContent value="balance" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <h3 className="text-lg font-medium">Send Coins</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Recipient</label>
                  <div className="flex">
                    <div className="bg-gray-100 dark:bg-gray-800 p-2 flex items-center rounded-l-md border border-r-0 border-gray-300 dark:border-gray-700">
                      <User size={18} className="text-gray-500 dark:text-gray-400" />
                    </div>
                    <Input
                      value={recipient}
                      onChange={(e) => setRecipient(e.target.value)}
                      placeholder="Username"
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Amount</label>
                  <div className="flex">
                    <div className="bg-gray-100 dark:bg-gray-800 p-2 flex items-center rounded-l-md border border-r-0 border-gray-300 dark:border-gray-700">
                      <Inbox size={18} className="text-gray-500 dark:text-gray-400" />
                    </div>
                    <Input
                      value={amount}
                      onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ''))}
                      type="number"
                      placeholder="0"
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <Button 
                  onClick={handleSend}
                  disabled={!amount || Number(amount) <= 0 || Number(amount) > profile.stars || !recipient}
                  className="w-full bg-primary hover:bg-primary/90 text-white"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Send Coins
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <h3 className="text-lg font-medium">Earn More Coins</h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-2 border border-gray-200 dark:border-gray-800 rounded-lg">
                  <div>
                    <p className="font-medium">Create Content</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Create photos or videos</p>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => window.location.hash = "create"}
                    className="border-primary/20 text-primary"
                  >
                    Create
                  </Button>
                </div>
                
                <div className="flex items-center justify-between p-2 border border-gray-200 dark:border-gray-800 rounded-lg">
                  <div>
                    <p className="font-medium">Daily Bonus</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Claim your daily reward</p>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => window.location.hash = "dashboard"}
                    className="border-primary/20 text-primary"
                  >
                    Claim
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader>
              <h3 className="text-lg font-medium">Recent Transactions</h3>
            </CardHeader>
            <CardContent>
              <div className="divide-y dark:divide-gray-800">
                {transactions.map(transaction => (
                  <div key={transaction.id} className="py-3 flex items-start">
                    <div className={`p-2 rounded-full mr-3 ${transaction.type === "receive" ? "bg-secondary/10" : "bg-primary/10"}`}>
                      {transaction.type === "receive" ? (
                        <Inbox size={16} className="text-secondary" />
                      ) : (
                        <Send size={16} className="text-primary" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <p className="font-medium">
                          {transaction.type === "receive" ? "Received from" : "Sent to"} {transaction.type === "receive" ? transaction.from : transaction.to}
                        </p>
                        <p className={`font-bold ${transaction.type === "receive" ? "text-secondary" : "text-primary"}`}>
                          {transaction.type === "receive" ? "+" : "-"}{transaction.amount}
                        </p>
                      </div>
                      <div className="flex justify-between text-xs">
                        <p className="text-gray-500 dark:text-gray-400">{transaction.note}</p>
                        <p className="text-gray-500 dark:text-gray-400 flex items-center">
                          <Clock size={12} className="mr-1" />
                          {transaction.date.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
                
                {transactions.length === 0 && (
                  <div className="py-6 text-center">
                    <p className="text-gray-500 dark:text-gray-400">No transactions yet</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="withdraw" className="space-y-4">
          <Card className="overflow-hidden">
            <div className="bg-gradient-to-r from-secondary to-secondary/80 text-white p-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Withdrawal</h3>
                <ArrowDown size={20} />
              </div>
              <p className="text-sm opacity-90 mt-1">Convert coins to real money</p>
            </div>
            
            <CardContent className="pt-5">
              <div className="text-center py-8 px-4 flex flex-col items-center">
                <div className="w-16 h-16 mb-4 rounded-full bg-secondary/10 flex items-center justify-center">
                  <Download className="h-8 w-8 text-secondary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Withdrawal Coming Soon</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4 max-w-xs">
                  We're working on enabling withdrawals so you can convert your coins to real money. Stay tuned!
                </p>
                
                <Badge variant="outline" className="bg-secondary/10 text-secondary border-secondary/20">
                  Coming Soon
                </Badge>
              </div>
            </CardContent>
            
            <CardFooter className="bg-gray-50 dark:bg-gray-900 border-t dark:border-gray-800">
              <div className="w-full text-sm text-center text-gray-500 dark:text-gray-400">
                Current minimum withdrawal: 1000 coins
              </div>
            </CardFooter>
          </Card>
          
          {profile.stars >= 1000 ? (
            <div className="bg-secondary/10 border border-secondary/20 rounded-lg p-3 text-sm">
              <p className="text-secondary font-medium">You're eligible for withdrawal!</p>
              <p className="text-gray-600 dark:text-gray-300 mt-1">This feature will be available soon.</p>
            </div>
          ) : (
            <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3 text-sm">
              <p className="text-gray-600 dark:text-gray-300">You need {1000 - profile.stars} more coins to be eligible for withdrawal</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Wallet;
