
import React from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

interface MediaFiltersProps {
  selectedFilter: string;
  onSelectFilter: (filter: string) => void;
}

const filters = [
  { id: "original", name: "Original", class: "" },
  { id: "grayscale", name: "Black & White", class: "grayscale" },
  { id: "sepia", name: "Vintage", class: "sepia" },
  { id: "vivid", name: "Vivid", class: "saturate-150 contrast-125" },
  { id: "warm", name: "Warm", class: "brightness-105 sepia-[.25]" },
  { id: "cool", name: "Cool", class: "hue-rotate-15 brightness-105" },
  { id: "dramatic", name: "Dramatic", class: "contrast-125 brightness-75" },
  { id: "sharp", name: "Sharp", class: "contrast-125 brightness-100" },
  { id: "matte", name: "Matte", class: "brightness-105 contrast-90 saturate-95" }
];

const MediaFilters: React.FC<MediaFiltersProps> = ({ selectedFilter, onSelectFilter }) => {
  return (
    <Card className="p-4">
      <h3 className="text-lg font-semibold mb-3">Filters</h3>
      <div className="grid grid-cols-3 gap-3">
        {filters.map((filter) => (
          <Button
            key={filter.id}
            variant="outline"
            className={`h-auto py-2 relative ${selectedFilter === filter.id ? 'border-primary ring-1 ring-primary' : ''}`}
            onClick={() => onSelectFilter(filter.id)}
          >
            {selectedFilter === filter.id && (
              <CheckCircle className="h-4 w-4 absolute top-1 right-1 text-primary" />
            )}
            <span className="text-sm">{filter.name}</span>
          </Button>
        ))}
      </div>
    </Card>
  );
};

export default MediaFilters;
