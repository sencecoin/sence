
import { useState, useEffect } from "react";
import { useGameContext } from "@/context/GameContext";
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from "@/components/ui/command";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Search as SearchIcon, UserPlus, Check, Star } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export function Search() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { users, currentUser, followUser, unfollowUser } = useGameContext();
  const navigate = useNavigate();
  const { toast } = useToast();

  // Filter users based on search query
  const filteredUsers = users.filter(user => 
    user.id !== currentUser?.id && 
    (user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
     user.bio.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleFollow = (userId: string) => {
    followUser(userId);
    toast({
      title: "Success",
      description: "User followed successfully!",
    });
  };

  const handleUnfollow = (userId: string) => {
    unfollowUser(userId);
    toast({
      title: "Success",
      description: "User unfollowed successfully!",
    });
  };

  const handleViewProfile = (userId: string) => {
    setOpen(false);
    navigate(`/profile/${userId}`);
  };

  return (
    <>
      <Button 
        variant="outline" 
        size="icon" 
        className="rounded-full bg-gray-50 text-gray-700"
        onClick={() => setOpen(true)}
      >
        <SearchIcon className="h-5 w-5" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Search Users</DialogTitle>
          </DialogHeader>
          <Command>
            <CommandInput 
              placeholder="Search users by name or bio..." 
              value={searchQuery}
              onValueChange={setSearchQuery}
            />
            <CommandList>
              <CommandEmpty>No users found.</CommandEmpty>
              <CommandGroup>
                {filteredUsers.map(user => (
                  <CommandItem 
                    key={user.id}
                    className="flex items-center justify-between p-2"
                  >
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        {user.profileImage ? (
                          <img src={user.profileImage} alt={user.username} className="h-full w-full object-cover" />
                        ) : (
                          <div className="h-full w-full rounded-full bg-gradient-to-r from-pink-500 to-violet-500 flex items-center justify-center text-white">
                            {user.username[0].toUpperCase()}
                          </div>
                        )}
                      </Avatar>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-1">
                          <span className="font-medium">{user.username}</span>
                          {user.isVerified && (
                            <Badge variant="secondary" className="h-4 px-1">✓</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Star className="h-3 w-3" />
                          <span>Level {user.level}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewProfile(user.id)}
                      >
                        View
                      </Button>
                      {currentUser?.following.includes(user.id) ? (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUnfollow(user.id)}
                        >
                          <Check className="h-4 w-4 mr-1" />
                          Following
                        </Button>
                      ) : (
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleFollow(user.id)}
                        >
                          <UserPlus className="h-4 w-4 mr-1" />
                          Follow
                        </Button>
                      )}
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </DialogContent>
      </Dialog>
    </>
  );
}
