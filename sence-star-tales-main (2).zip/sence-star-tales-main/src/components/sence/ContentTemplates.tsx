import React from 'react';
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { BookOpen, Clock, Sparkles, Heart, Camera, MapPin, Sun, Cloud, Coffee, Music, Star } from "lucide-react";

interface ContentTemplatesProps {
  onTemplateSelect: (template: string) => void;
}

const templates = [
  {
    id: "daily",
    icon: <Sun className="h-4 w-4" />,
    title: "Daily Update",
    samples: [
      "Good morning! Starting my day with ☕ and positive vibes. What are you up to today?",
      "Evening thoughts: reflecting on a productive day. Grateful for the small wins! ✨",
      "Sunday reset mode: preparing for the week ahead with some self-care and planning. How do you prepare for your week?"
    ]
  },
  {
    id: "travel",
    icon: <MapPin className="h-4 w-4" />,
    title: "Travel",
    samples: [
      "Exploring new corners of the world! Today's adventure: [location]. Have you ever been here?",
      "The view from my window today looks like this. Sometimes you don't need to go far to find beauty. 🌄",
      "Travel tip: always pack [item] when visiting [place]. It's been a lifesaver on this trip!"
    ]
  },
  {
    id: "photo",
    icon: <Camera className="h-4 w-4" />,
    title: "Photography",
    samples: [
      "Captured this moment during golden hour. No filter needed when nature provides the perfect lighting. 📸",
      "Playing with shadows and light in today's photography experiment. What do you think of the results?",
      "Street photography series, part 3: The stories we see in strangers' faces. 🖤"
    ]
  },
  {
    id: "quote",
    icon: <BookOpen className="h-4 w-4" />,
    title: "Quotes & Inspiration",
    samples: [
      "\"The best way to predict the future is to create it.\" — Wise words I'm living by this week. What's your favorite quote?",
      "Today's affirmation: I am capable of amazing things. ✨ Share yours below!",
      "A lesson I recently learned: [your insight]. Sometimes the hardest experiences teach us the most valuable lessons."
    ]
  },
  {
    id: "throwback",
    icon: <Clock className="h-4 w-4" />,
    title: "Throwback",
    samples: [
      "#ThrowbackThursday to this time last year. So much has changed since then! 🔄",
      "Found this gem while scrolling through old photos. The memories attached to this moment... 💖",
      "Five years ago today vs now. Growth happens in unexpected ways. 🌱"
    ]
  },
  {
    id: "wellness",
    icon: <Heart className="h-4 w-4" />,
    title: "Wellness",
    samples: [
      "New workout routine has me feeling stronger every day. What's your favorite way to move your body?",
      "Mental health check-in: taking time for meditation today. How do you prioritize your mental wellbeing?",
      "Recipe share: this nutritious [meal] has been my go-to this week. Simple, delicious, and good for you!"
    ]
  },
  {
    id: "creative",
    icon: <Sparkles className="h-4 w-4" />,
    title: "Creative",
    samples: [
      "Latest project coming to life! Here's a sneak peek of what I've been working on. 🎨",
      "Writer's block breakthrough! After weeks of struggling, the words are finally flowing again.",
      "My creative process involves [your process]. What helps you get into your creative zone?"
    ]
  },
  {
    id: "weather",
    icon: <Cloud className="h-4 w-4" />,
    title: "Weather",
    samples: [
      "Perfect day for a picnic! The sun is shining and there's a gentle breeze. ☀️",
      "Cozy rainy day vibes. The perfect excuse to stay in with a good book and hot tea. 🌧️",
      "First snow of the season! Everything looks magical covered in white. ❄️"
    ]
  },
  {
    id: "coffee",
    icon: <Coffee className="h-4 w-4" />,
    title: "Coffee",
    samples: [
      "Morning coffee ritual: a moment of calm before the day begins. How do you start your mornings?",
      "Discovered a new coffee spot in town! Their [drink] is now my favorite afternoon pick-me-up.",
      "Home-brewed perfection. Finally mastered the art of pour-over coffee after months of practice. ☕"
    ]
  },
  {
    id: "music",
    icon: <Music className="h-4 w-4" />,
    title: "Music",
    samples: [
      "This song has been on repeat all week. Anyone else love [artist]'s new album?",
      "Throwback to my first concert experience seeing [artist]. What was your first concert?",
      "Making playlists is my love language. Here's what I'm listening to while [activity]. 🎵"
    ]
  }
];

const ContentTemplates: React.FC<ContentTemplatesProps> = ({ onTemplateSelect }) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center">
        <Star className="h-5 w-5 text-yellow-500 mr-2" />
        <h3 className="text-lg font-semibold">Content Templates</h3>
      </div>
      
      <p className="text-sm text-gray-500">
        Choose a template to jumpstart your post. Click on any suggestion to use it.
      </p>
      
      <ScrollArea className="h-[400px] pr-4">
        <div className="space-y-4">
          {templates.map((category) => (
            <Card key={category.id} className="p-4">
              <div className="flex items-center mb-2">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center mr-2">
                  {category.icon}
                </div>
                <h4 className="font-semibold">{category.title}</h4>
              </div>
              
              <div className="space-y-2 mt-3">
                {category.samples.map((sample, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start text-left h-auto py-3 font-normal hover:bg-gray-100 dark:hover:bg-gray-800"
                    onClick={() => onTemplateSelect(sample)}
                  >
                    {sample}
                  </Button>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ContentTemplates;
