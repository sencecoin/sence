
import { useState, useRef } from "react";
import { useGameContext } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Video, Plus, X, Coins } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Card } from "@/components/ui/card";

const ReelUpload = ({ onComplete }: { onComplete: () => void }) => {
  const { createPost, availableTopics, availableHashtags, currentUser, addStars } = useGameContext();
  const { toast } = useToast();
  const [caption, setCaption] = useState("");
  const [topic, setTopic] = useState(availableTopics[0]);
  const [selectedHashtags, setSelectedHashtags] = useState<string[]>([]);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showCoinInfo, setShowCoinInfo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleVideoSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setVideoUrl(url);
      toast({
        title: "Video selected!",
        description: "Your video has been successfully selected.",
      });
    }
  };

  const handleHashtagToggle = (hashtag: string) => {
    if (selectedHashtags.includes(hashtag)) {
      setSelectedHashtags(selectedHashtags.filter(h => h !== hashtag));
    } else {
      if (selectedHashtags.length < 5) {
        setSelectedHashtags([...selectedHashtags, hashtag]);
      } else {
        toast({
          title: "Maximum 5 hashtags",
          description: "You can select up to 5 hashtags for your reel",
          variant: "destructive",
        });
      }
    }
  };
  
  const clearVideo = () => {
    if (videoUrl) {
      URL.revokeObjectURL(videoUrl);
      setVideoUrl(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      toast({
        title: "Login required",
        description: "Please login to upload reels",
        variant: "destructive",
      });
      return;
    }
    
    if (!videoUrl) {
      toast({
        title: "Video required",
        description: "Please select a video for your reel",
        variant: "destructive",
      });
      return;
    }
    
    if (!caption) {
      toast({
        title: "Caption required",
        description: "Please add a caption for your reel",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedHashtags.length === 0) {
      toast({
        title: "Hashtags required",
        description: "Please select at least one hashtag",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    
    // Simulate upload delay
    setTimeout(() => {
      createPost({
        type: "video",
        topic,
        caption,
        hashtags: selectedHashtags,
      });
      
      // Give coins for uploading a reel
      addStars(20);
      
      toast({
        title: "Reel created!",
        description: "Your reel has been uploaded successfully. You earned 20 coins!",
      });
      
      setIsUploading(false);
      
      // Reset form
      setCaption("");
      setTopic(availableTopics[0]);
      setSelectedHashtags([]);
      setVideoUrl(null);
      
      onComplete();
    }, 1500);
  };
  
  return (
    <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-100">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500 text-transparent bg-clip-text">
          Create New Reel
        </h3>
        <Button
          variant="outline"
          size="sm"
          className="text-primary border-primary/20"
          onClick={() => setShowCoinInfo(!showCoinInfo)}
        >
          <Coins className="h-4 w-4 mr-1" />
          Earn Coins
        </Button>
      </div>
      
      {showCoinInfo && (
        <Card className="p-4 mb-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-100">
          <h4 className="font-medium text-blue-700 mb-2">Earn Coins with Your Reels!</h4>
          <ul className="text-sm text-blue-600 space-y-2">
            <li className="flex items-center">
              <Coins className="h-3.5 w-3.5 mr-2" />
              <span>20 coins for each reel upload</span>
            </li>
            <li className="flex items-center">
              <Coins className="h-3.5 w-3.5 mr-2" />
              <span>5 coins for each like you receive</span>
            </li>
            <li className="flex items-center">
              <Coins className="h-3.5 w-3.5 mr-2" />
              <span>2 coins for each comment on your reels</span>
            </li>
          </ul>
          <p className="text-xs text-blue-500 mt-2">
            Use coins to boost your content and unlock special features!
          </p>
        </Card>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Video upload */}
        <div className="relative">
          <input
            type="file"
            accept="video/*"
            onChange={handleVideoSelect}
            className="hidden"
            id="video-upload"
            ref={fileInputRef}
          />
          <div 
            className={`border-2 border-dashed rounded-lg p-8 transition-all cursor-pointer bg-gray-50 ${
              videoUrl ? 'border-blue-300' : 'border-gray-200 hover:border-primary'
            }`}
            onClick={() => !videoUrl && document.getElementById("video-upload")?.click()}
          >
            {videoUrl ? (
              <div className="relative">
                <video src={videoUrl} className="max-h-64 mx-auto rounded" controls />
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  className="absolute top-2 right-2 h-7 w-7"
                  onClick={(e) => {
                    e.stopPropagation();
                    clearVideo();
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <Video className="h-12 w-12 text-gray-400 mb-2" />
                <p className="text-sm text-gray-500 text-center">
                  Click to select a video for your reel
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="mt-4 text-primary border-primary/20"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Select Video
                </Button>
              </div>
            )}
          </div>
        </div>
        
        {/* Caption */}
        <div className="space-y-2">
          <Label htmlFor="caption" className="text-gray-700 flex justify-between">
            <span>Caption</span>
            <span className={`text-xs ${caption.length > 2000 ? 'text-red-500' : 'text-gray-500'}`}>
              {caption.length}/2200
            </span>
          </Label>
          <Input
            id="caption"
            placeholder="Write a caption for your reel..."
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            className="focus-visible:ring-primary"
            maxLength={2200}
          />
        </div>
        
        {/* Topic selection */}
        <div className="space-y-2">
          <Label htmlFor="topic" className="text-gray-700">Topic</Label>
          <select
            id="topic"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md focus:outline-none focus-visible:ring-1 focus-visible:ring-primary"
          >
            {availableTopics.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>
        
        {/* Hashtags */}
        <div className="space-y-2">
          <Label className="text-gray-700 flex justify-between">
            <span>Add hashtags</span>
            <span className="text-xs text-gray-500">
              {selectedHashtags.length}/5 selected
            </span>
          </Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {availableHashtags.map((hashtag) => (
              <button
                key={hashtag}
                type="button"
                onClick={() => handleHashtagToggle(hashtag)}
                className={`px-3 py-1 rounded-full text-xs transition-all ${
                  selectedHashtags.includes(hashtag)
                    ? "bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {hashtag}
              </button>
            ))}
          </div>
        </div>
        
        {/* Submit button */}
        <Button
          type="submit"
          className="w-full bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500 text-white hover:opacity-90 transition-opacity"
          disabled={isUploading}
        >
          {isUploading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Uploading...
            </>
          ) : (
            'Share Reel'
          )}
        </Button>
      </form>
    </div>
  );
};

export default ReelUpload;
