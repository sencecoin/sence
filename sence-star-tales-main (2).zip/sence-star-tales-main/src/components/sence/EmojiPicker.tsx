
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface EmojiPickerProps {
  onSelect: (emoji: string) => void;
}

const emojis = [
  "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇",
  "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚",
  "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩",
  "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣",
  "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "❣️", "💕", "💞",
  "👍", "👎", "👏", "🙌", "👐", "🤲", "🤝", "👊", "✊", "🤛",
  "🔥", "✨", "🎉", "🎊", "💯", "⭐", "🌟", "💫", "💥", "💢"
];

const EmojiPicker: React.FC<EmojiPickerProps> = ({ onSelect }) => {
  const emojiCategories = [
    { name: "Smileys", emojis: emojis.slice(0, 20) },
    { name: "Hearts", emojis: emojis.slice(20, 30) },
    { name: "Hands", emojis: emojis.slice(30, 40) },
    { name: "Symbols", emojis: emojis.slice(40, 50) },
  ];
  
  return (
    <Card className="w-60 p-2 shadow-lg">
      <div className="grid grid-cols-5 gap-1">
        {emojis.map((emoji, index) => (
          <button
            key={index}
            onClick={() => onSelect(emoji)}
            className="w-full h-10 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 rounded cursor-pointer text-xl transition-colors"
          >
            {emoji}
          </button>
        ))}
      </div>
      <div className="border-t mt-2 pt-1 text-center">
        <span className="text-xs text-gray-500">Click emoji to add</span>
      </div>
    </Card>
  );
};

export default EmojiPicker;
