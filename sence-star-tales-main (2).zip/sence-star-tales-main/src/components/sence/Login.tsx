
import { useState } from "react";
import { useGameContext } from "@/context/GameContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Instagram, Lock } from "lucide-react";

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, register } = useGameContext();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !password) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    if (isLogin) {
      const success = login(username, password);
      if (success) {
        toast({
          title: "Success",
          description: "You have successfully logged in",
        });
      } else {
        toast({
          title: "Error",
          description: "Invalid username or password. Try food_guru, tech_geek or travel_lover",
          variant: "destructive",
        });
      }
    } else {
      const success = register(username, password);
      if (success) {
        toast({
          title: "Success",
          description: "Your account has been created",
        });
      } else {
        toast({
          title: "Error",
          description: "Username already exists",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4">
      <Card className="w-full max-w-md p-6 bg-white shadow-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="h-20 w-20 rounded-xl bg-gradient-to-tr from-[#FFDC80] via-[#FCAF45] via-[#F77737] via-[#F56040] via-[#FD1D1D] via-[#E1306C] via-[#C13584] to-[#833AB4] p-0.5">
              <div className="h-full w-full bg-white rounded-xl flex items-center justify-center">
                <Instagram size={40} className="instagram-gradient text-transparent bg-clip-text" />
              </div>
            </div>
          </div>
          
          <h1 className="text-2xl font-bold mb-2">Sence Coin</h1>
          <p className="text-gray-500 text-sm text-center">
            Sign in to connect with creators and earn rewards.
          </p>
        </div>

        <Button
          variant="outline"
          className="w-full border-gray-200 mb-4 bg-blue-50 text-blue-600 flex items-center justify-center"
          type="button"
        >
          <Lock className="h-4 w-4 mr-2" /> Log in with Facebook
        </Button>

        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">OR</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              className="bg-gray-50 border-gray-200"
            />
          </div>

          <div className="space-y-2">
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="bg-gray-50 border-gray-200"
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-primary to-accent text-white hover:opacity-90 transition-opacity"
          >
            {isLogin ? "Log In" : "Sign Up"}
          </Button>
          
          {isLogin && (
            <div className="text-center">
              <Button variant="link" className="text-xs text-blue-600 p-0">
                Forgot password?
              </Button>
            </div>
          )}
        </form>

        <div className="mt-6 text-center text-sm text-gray-500">
          <p>
            {isLogin
              ? "Don't have an account? "
              : "Already have an account? "}
            <Button
              variant="link"
              className="p-0 font-semibold text-blue-500"
              onClick={() => setIsLogin(!isLogin)}
              type="button"
            >
              {isLogin ? "Sign up" : "Log in"}
            </Button>
          </p>
        </div>
      </Card>

      <div className="mt-6 text-center text-sm text-gray-500">
        <p>Get the app.</p>
        <div className="flex justify-center space-x-4 mt-4">
          <div className="h-10 w-32 bg-black rounded-md flex items-center justify-center text-white">
            App Store
          </div>
          <div className="h-10 w-32 bg-black rounded-md flex items-center justify-center text-white">
            Google Play
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
