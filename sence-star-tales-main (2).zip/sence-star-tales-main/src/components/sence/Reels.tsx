
import { useState, useRef, useEffect } from "react";
import { useGameContext } from "@/context/GameContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { 
  Heart, 
  MessageSquare, 
  Share2, 
  User, 
  Send, 
  X, 
  Volume2, 
  VolumeX,
  Bookmark,
  MoreHorizontal,
  Play,
  Pause,
  Repeat,
  Download,
  Flag,
  Filter,
  Music,
  Clock,
  Sparkles,
  Trophy,
  Star
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Progress } from "@/components/ui/progress";
import { Link } from "react-router-dom";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Reels = () => {
  const { feedPosts, likePost, addComment, currentUser, users } = useGameContext();
  const { toast } = useToast();
  const [activeReel, setActiveReel] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [commentEmoji, setCommentEmoji] = useState("👍");
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [showEffects, setShowEffects] = useState(false);
  const [showMusicOverlay, setShowMusicOverlay] = useState(false);
  const [isDoubleTapLiking, setIsDoubleTapLiking] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [timeWatched, setTimeWatched] = useState(0);
  const [autoplay, setAutoplay] = useState(true);
  const [showReelInfo, setShowReelInfo] = useState(false);
  const [reelViewers, setReelViewers] = useState([]);
  const [savedReels, setSavedReels] = useState<string[]>([]);
  
  const commentInputRef = useRef<HTMLInputElement>(null);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const progressInterval = useRef<number | null>(null);
  const doubleTapTimer = useRef<number | null>(null);
  const tapCount = useRef(0);
  const videoContainerRef = useRef<HTMLDivElement>(null);
  
  // Only show video type posts for reels
  const reelPosts = feedPosts.filter(post => post.type === "video");

  useEffect(() => {
    // Clear any existing interval
    if (progressInterval.current) {
      window.clearInterval(progressInterval.current);
    }

    // Setup new interval for progress bar
    if (isPlaying) {
      progressInterval.current = window.setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + 0.5;
          if (newProgress >= 100) {
            // Progress complete, move to next reel if autoplay is on
            if (autoplay) {
              handleNext();
            } else {
              setIsPlaying(false);
              return 100;
            }
            return 0;
          }
          return newProgress;
        });
        
        // Track time watched
        setTimeWatched(prev => prev + 0.1);
      }, 100); // Update every 100ms
    }

    // Cleanup interval on component unmount
    return () => {
      if (progressInterval.current) {
        window.clearInterval(progressInterval.current);
      }
    };
  }, [activeReel, isPlaying, autoplay]);

  // Handle video play/pause when visibility changes
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsPlaying(false);
      } else if (autoplay) {
        setIsPlaying(true);
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [autoplay]);

  // Handle video element references
  useEffect(() => {
    videoRefs.current = videoRefs.current.slice(0, reelPosts.length);
  }, [reelPosts]);

  // Handle video playback
  useEffect(() => {
    videoRefs.current.forEach((video, index) => {
      if (!video) return;
      
      if (index === activeReel && isPlaying) {
        video.play().catch(e => console.error("Video play error:", e));
      } else {
        video.pause();
      }
      
      video.muted = isMuted;
    });
  }, [activeReel, isPlaying, isMuted]);
  
  // Simulate gaining coins when watching videos
  useEffect(() => {
    if (timeWatched > 10 && currentUser) {
      toast({
        title: "Earned rewards!",
        description: "You earned 5 coins for watching content",
      });
      setTimeWatched(0);
    }
  }, [timeWatched, currentUser, toast]);
  
  const handleNext = () => {
    setProgress(0);
    if (activeReel < reelPosts.length - 1) {
      setActiveReel(activeReel + 1);
    } else {
      setActiveReel(0); // Loop back to first reel
    }
    setShowComments(false);
    setShowFilters(false);
    setShowEffects(false);
    setShowMusicOverlay(false);
  };
  
  const handlePrevious = () => {
    setProgress(0);
    if (activeReel > 0) {
      setActiveReel(activeReel - 1);
    } else {
      setActiveReel(reelPosts.length - 1); // Loop to last reel
    }
    setShowComments(false);
    setShowFilters(false);
    setShowEffects(false);
    setShowMusicOverlay(false);
  };
  
  const handleLike = () => {
    if (!currentUser) {
      toast({
        title: "Login required",
        description: "Please login to like reels",
        variant: "destructive",
      });
      return;
    }
    
    const currentReel = reelPosts[activeReel];
    likePost(currentReel.id);
    
    toast({
      title: "Liked!",
      description: `You liked ${getPostCreator(currentReel.userId)?.username || 'this'} reel`,
    });
  };
  
  const handleDoubleTap = (e: React.MouseEvent) => {
    tapCount.current += 1;
    
    if (tapCount.current === 1) {
      doubleTapTimer.current = window.setTimeout(() => {
        // Single tap - reset
        tapCount.current = 0;
        doubleTapTimer.current = null;
      }, 300);
    } else if (tapCount.current === 2) {
      // Double tap detected
      clearTimeout(doubleTapTimer.current!);
      tapCount.current = 0;
      doubleTapTimer.current = null;
      
      // Show heart animation at tap location
      const rect = videoContainerRef.current?.getBoundingClientRect();
      if (rect) {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Set position for heart animation
        setIsDoubleTapLiking(true);
        
        // Like the video
        handleLike();
        
        // Hide heart animation after animation completes
        setTimeout(() => {
          setIsDoubleTapLiking(false);
        }, 1000);
      }
    }
  };
  
  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };
  
  const handleComment = () => {
    setShowComments(!showComments);
    
    if (!showComments && commentInputRef.current) {
      setTimeout(() => {
        commentInputRef.current?.focus();
      }, 100);
    }
  };
  
  const handleSubmitComment = () => {
    if (!currentUser) {
      toast({
        title: "Login required",
        description: "Please login to comment on reels",
        variant: "destructive",
      });
      return;
    }
    
    if (!commentText.trim()) {
      toast({
        title: "Empty comment",
        description: "Please write something in your comment",
        variant: "destructive",
      });
      return;
    }
    
    const currentReel = reelPosts[activeReel];
    addComment(currentReel.id, commentText, commentEmoji);
    
    toast({
      title: "Comment added!",
      description: `Your comment was added to ${getPostCreator(currentReel.userId)?.username || 'this'} reel`,
    });
    
    setCommentText("");
  };

  const handleShare = () => {
    toast({
      title: "Share feature",
      description: "Shared with your friends!",
    });
  };

  const handleSaveReel = () => {
    const currentReel = reelPosts[activeReel];
    
    if (savedReels.includes(currentReel.id)) {
      setSavedReels(savedReels.filter(id => id !== currentReel.id));
      toast({
        title: "Reel removed!",
        description: "This reel has been removed from your collection",
      });
    } else {
      setSavedReels([...savedReels, currentReel.id]);
      toast({
        title: "Reel saved!",
        description: "This reel has been saved to your collection",
      });
    }
  };
  
  const handleDownloadReel = () => {
    toast({
      title: "Downloading reel",
      description: "Your reel will be saved to your device",
    });
  };
  
  const handleReportReel = () => {
    setShowReportForm(true);
  };
  
  const submitReport = () => {
    if (!reportReason.trim()) {
      toast({
        title: "Report reason required",
        description: "Please provide a reason for reporting this reel",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Report submitted",
      description: "Thank you for helping keep our community safe",
    });
    
    setShowReportForm(false);
    setReportReason("");
  };
  
  const toggleFilters = () => {
    setShowFilters(!showFilters);
    setShowEffects(false);
    setShowMusicOverlay(false);
  };
  
  const toggleEffects = () => {
    setShowEffects(!showEffects);
    setShowFilters(false);
    setShowMusicOverlay(false);
  };
  
  const toggleMusicOverlay = () => {
    setShowMusicOverlay(!showMusicOverlay);
    setShowFilters(false);
    setShowEffects(false);
  };
  
  const toggleAutoplay = () => {
    setAutoplay(!autoplay);
    
    toast({
      title: autoplay ? "Autoplay disabled" : "Autoplay enabled",
      description: autoplay ? "Videos will no longer play automatically" : "Videos will play automatically",
    });
  };
  
  const toggleReelInfo = () => {
    setShowReelInfo(!showReelInfo);
  };
  
  const getPostCreator = (userId: string) => {
    return users.find(user => user.id === userId);
  };
  
  const isReelLikedByUser = (postId: string) => {
    if (!currentUser) return false;
    
    const reel = reelPosts.find(post => post.id === postId);
    return reel ? reel.likedBy.includes(currentUser.id) : false;
  };
  
  const isReelSavedByUser = (postId: string) => {
    return savedReels.includes(postId);
  };
  
  // Apply filter to video
  const applyFilter = (filterName: string) => {
    const videoElement = videoRefs.current[activeReel];
    if (!videoElement) return;
    
    // Reset filters
    videoElement.style.filter = "";
    
    // Apply selected filter
    switch (filterName) {
      case "vintage":
        videoElement.style.filter = "sepia(0.5) contrast(1.2)";
        break;
      case "black-white":
        videoElement.style.filter = "grayscale(1)";
        break;
      case "bright":
        videoElement.style.filter = "brightness(1.3) contrast(1.1)";
        break;
      case "warm":
        videoElement.style.filter = "sepia(0.3) saturate(1.6)";
        break;
      case "cool":
        videoElement.style.filter = "hue-rotate(30deg) saturate(0.8)";
        break;
      default:
        break;
    }
    
    toast({
      title: `${filterName} filter applied`,
    });
  };
  
  // Apply effect to video
  const applyEffect = (effectName: string) => {
    const videoElement = videoRefs.current[activeReel];
    if (!videoElement) return;
    
    // Reset effects
    videoElement.style.animation = "";
    
    // Apply selected effect
    switch (effectName) {
      case "bounce":
        videoElement.style.animation = "bounce 2s infinite";
        break;
      case "pulse":
        videoElement.style.animation = "pulse 1.5s infinite";
        break;
      case "shake":
        videoElement.style.animation = "shake 0.5s infinite";
        break;
      case "flash":
        videoElement.style.animation = "flash 1s infinite";
        break;
      default:
        break;
    }
    
    toast({
      title: `${effectName} effect applied`,
    });
  };
  
  // Generate some rewards for watching reels
  const claimReward = () => {
    if (!currentUser) {
      toast({
        title: "Login required",
        description: "Please login to claim rewards",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "Reward claimed!",
      description: "You earned 10 Sence coins for watching reels",
    });
  };
  
  if (reelPosts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-gray-500">
        <p className="text-center">No reels available.</p>
        <p className="text-sm mt-2">Create a video post to see reels here!</p>
        <Button variant="outline" className="mt-4">
          <Link to="/?tab=create">Create a Reel</Link>
        </Button>
      </div>
    );
  }
  
  const currentReel = reelPosts[activeReel];
  const postCreator = getPostCreator(currentReel.userId);
  const isLiked = isReelLikedByUser(currentReel.id);
  const isSaved = isReelSavedByUser(currentReel.id);
  
  return (
    <div className="pb-20">
      <div className="relative h-[75vh] bg-black rounded-xl overflow-hidden">
        {/* Video content */}
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-gray-800/20 to-gray-900/40">
          <div 
            ref={videoContainerRef}
            className="w-full h-full flex items-center justify-center relative"
            onClick={handleDoubleTap}
          >
            {/* Simulated video element */}
            <video 
              ref={el => videoRefs.current[activeReel] = el}
              className="h-full w-full object-cover object-center"
              poster="https://source.unsplash.com/random/800x1200/?tech"
              onClick={togglePlayback}
              loop
            >
              <source src="https://example.com/video.mp4" type="video/mp4" />
            </video>

            {/* Double-tap heart animation */}
            {isDoubleTapLiking && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Heart className="h-24 w-24 text-red-500 fill-red-500 animate-scale-in" />
              </div>
            )}

            {/* Play/Pause overlay */}
            {!isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center" onClick={togglePlayback}>
                <div className="bg-black/30 p-6 rounded-full backdrop-blur-sm">
                  <Play className="h-12 w-12 text-white" />
                </div>
              </div>
            )}
            
            {/* Video controls overlay - tap to show/hide */}
            <div className="absolute bottom-5 left-0 right-0 flex justify-center">
              <div className="bg-black/30 backdrop-blur-sm rounded-full px-4 py-2 flex space-x-4">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 rounded-full"
                  onClick={() => handlePrevious()}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="19 20 9 12 19 4 19 20"></polygon><line x1="5" x2="5" y1="19" y2="5"></line></svg>
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 rounded-full"
                  onClick={togglePlayback}
                >
                  {isPlaying ? (
                    <Pause className="h-6 w-6" />
                  ) : (
                    <Play className="h-6 w-6" />
                  )}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 rounded-full"
                  onClick={() => handleNext()}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 4 15 12 5 20 5 4"></polygon><line x1="19" x2="19" y1="5" y2="19"></line></svg>
                </Button>
              </div>
            </div>
            
            {/* Effects overlay */}
            {showEffects && (
              <div className="absolute bottom-20 left-0 right-0 bg-black/70 py-4 backdrop-blur-sm">
                <div className="flex space-x-4 px-4 overflow-x-auto">
                  <Button onClick={() => applyEffect("none")} variant="outline" className="text-white border-white">Normal</Button>
                  <Button onClick={() => applyEffect("bounce")} variant="outline" className="text-white border-white">Bounce</Button>
                  <Button onClick={() => applyEffect("pulse")} variant="outline" className="text-white border-white">Pulse</Button>
                  <Button onClick={() => applyEffect("shake")} variant="outline" className="text-white border-white">Shake</Button>
                  <Button onClick={() => applyEffect("flash")} variant="outline" className="text-white border-white">Flash</Button>
                </div>
              </div>
            )}
            
            {/* Filters overlay */}
            {showFilters && (
              <div className="absolute bottom-20 left-0 right-0 bg-black/70 py-4 backdrop-blur-sm">
                <div className="flex space-x-4 px-4 overflow-x-auto">
                  <Button onClick={() => applyFilter("none")} variant="outline" className="text-white border-white">Normal</Button>
                  <Button onClick={() => applyFilter("vintage")} variant="outline" className="text-white border-white">Vintage</Button>
                  <Button onClick={() => applyFilter("black-white")} variant="outline" className="text-white border-white">B&W</Button>
                  <Button onClick={() => applyFilter("bright")} variant="outline" className="text-white border-white">Bright</Button>
                  <Button onClick={() => applyFilter("warm")} variant="outline" className="text-white border-white">Warm</Button>
                  <Button onClick={() => applyFilter("cool")} variant="outline" className="text-white border-white">Cool</Button>
                </div>
              </div>
            )}
            
            {/* Music overlay */}
            {showMusicOverlay && (
              <div className="absolute left-0 right-0 bottom-20 bg-black/70 py-4 backdrop-blur-sm">
                <div className="px-4">
                  <h3 className="text-white font-medium mb-2">Add Music to Reel</h3>
                  <div className="flex flex-col space-y-2">
                    <Button variant="outline" className="text-white border-white justify-start">
                      <Music className="w-5 h-5 mr-2" />
                      Popular Hit 1
                    </Button>
                    <Button variant="outline" className="text-white border-white justify-start">
                      <Music className="w-5 h-5 mr-2" />
                      Trending Sound 2
                    </Button>
                    <Button variant="outline" className="text-white border-white justify-start">
                      <Music className="w-5 h-5 mr-2" />
                      New Beat 3
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {/* Rewards banner */}
            <div className="absolute top-16 left-0 right-0 flex justify-center">
              <Button 
                onClick={claimReward} 
                className="bg-gradient-to-r from-yellow-400 to-amber-600 text-white border-none"
              >
                <Star className="w-4 h-4 mr-2" /> Claim 10 Coins Reward
              </Button>
            </div>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="absolute top-3 left-0 right-0 px-3">
          <Progress value={progress} className="h-1" />
        </div>

        {/* Top controls */}
        <div className="absolute top-3 right-3 flex space-x-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full bg-black/30 text-white hover:bg-black/50"
            onClick={toggleMute}
          >
            {isMuted ? (
              <VolumeX className="h-5 w-5" />
            ) : (
              <Volume2 className="h-5 w-5" />
            )}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full bg-black/30 text-white hover:bg-black/50"
              >
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-black/80 text-white border-gray-700">
              <DropdownMenuItem onClick={toggleReelInfo} className="cursor-pointer">
                <Clock className="w-4 h-4 mr-2" />
                Reel Info
              </DropdownMenuItem>
              <DropdownMenuItem onClick={toggleAutoplay} className="cursor-pointer">
                <Repeat className="w-4 h-4 mr-2" />
                {autoplay ? "Turn Off Autoplay" : "Turn On Autoplay"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDownloadReel} className="cursor-pointer">
                <Download className="w-4 h-4 mr-2" />
                Download
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleReportReel} className="cursor-pointer text-red-500">
                <Flag className="w-4 h-4 mr-2" />
                Report
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {/* Left side buttons */}
        <div className="absolute top-20 left-3 flex flex-col space-y-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full bg-black/30 text-white hover:bg-black/50"
            onClick={toggleFilters}
          >
            <Filter className="h-5 w-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full bg-black/30 text-white hover:bg-black/50"
            onClick={toggleEffects}
          >
            <Sparkles className="h-5 w-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="rounded-full bg-black/30 text-white hover:bg-black/50"
            onClick={toggleMusicOverlay}
          >
            <Music className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Navigation controls - tap left/right areas */}
        <div className="absolute inset-0 flex">
          <div className="w-1/2 h-full" onClick={handlePrevious}></div>
          <div className="w-1/2 h-full" onClick={handleNext}></div>
        </div>
        
        {/* Reel info overlay */}
        {showReelInfo && (
          <div className="absolute inset-0 bg-black/80 p-5 flex flex-col items-center justify-center">
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-3 right-3 text-white"
              onClick={toggleReelInfo}
            >
              <X className="h-6 w-6" />
            </Button>
            
            <div className="bg-gray-900/80 p-4 rounded-lg w-full max-w-md">
              <h2 className="text-white font-bold text-lg">Reel Information</h2>
              <div className="mt-2 space-y-2 text-gray-300">
                <p><span className="font-medium">Creator:</span> {postCreator?.username || "Unknown"}</p>
                <p><span className="font-medium">Posted:</span> {new Date(currentReel.createdAt).toLocaleDateString()}</p>
                <p><span className="font-medium">Views:</span> {currentReel.views || 0}</p>
                <p><span className="font-medium">Likes:</span> {currentReel.likes || 0}</p>
                <p><span className="font-medium">Comments:</span> {currentReel.comments.length || 0}</p>
                <p><span className="font-medium">Topics:</span> {currentReel.topic}</p>
                <div>
                  <span className="font-medium">Hashtags:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {currentReel.hashtags.map((tag, idx) => (
                      <span key={idx} className="text-blue-400 text-xs bg-blue-900/30 px-1.5 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button variant="outline" className="text-white border-white" onClick={toggleReelInfo}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Report form overlay */}
        {showReportForm && (
          <div className="absolute inset-0 bg-black/80 p-5 flex flex-col items-center justify-center">
            <div className="bg-gray-900/80 p-4 rounded-lg w-full max-w-md">
              <h2 className="text-white font-bold text-lg">Report this Reel</h2>
              <p className="text-gray-300 text-sm mt-1">Please tell us why you want to report this content</p>
              
              <div className="mt-4">
                <textarea
                  className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white"
                  rows={4}
                  placeholder="Describe why you're reporting this reel..."
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                ></textarea>
                
                <div className="mt-4 flex space-x-2 justify-end">
                  <Button variant="ghost" className="text-white" onClick={() => setShowReportForm(false)}>
                    Cancel
                  </Button>
                  <Button variant="destructive" onClick={submitReport}>
                    Submit Report
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Interaction buttons - Instagram-style */}
        <div className="absolute right-4 bottom-24 flex flex-col space-y-6">
          <div className="flex flex-col items-center space-y-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full bg-black/30 text-white hover:bg-black/50"
              onClick={handleLike}
            >
              <Heart className={`h-7 w-7 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
            <span className="text-xs text-white font-semibold">{currentReel.likes}</span>
          </div>
          
          <div className="flex flex-col items-center space-y-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full bg-black/30 text-white hover:bg-black/50"
              onClick={handleComment}
            >
              <MessageSquare className="h-7 w-7" />
            </Button>
            <span className="text-xs text-white font-semibold">{currentReel.comments.length}</span>
          </div>
          
          <div className="flex flex-col items-center space-y-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full bg-black/30 text-white hover:bg-black/50"
              onClick={handleShare}
            >
              <Share2 className="h-7 w-7" />
            </Button>
            <span className="text-xs text-white font-semibold">Share</span>
          </div>

          <div className="flex flex-col items-center space-y-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full bg-black/30 text-white hover:bg-black/50"
              onClick={handleSaveReel}
            >
              <Bookmark className={`h-7 w-7 ${isSaved ? 'fill-white' : ''}`} />
            </Button>
            <span className="text-xs text-white font-semibold">Save</span>
          </div>
          
          <div className="flex flex-col items-center space-y-1">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full bg-black/30 text-white hover:bg-black/50 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-yellow-500 via-red-500 to-purple-500 opacity-75"></div>
              <Trophy className="h-7 w-7 relative z-10" />
            </Button>
            <span className="text-xs text-white font-semibold">Earn</span>
          </div>
        </div>
        
        {/* User info - Instagram style */}
        <div className="absolute left-4 bottom-6 flex flex-col space-y-3">
          <Link to={`/profile/${currentReel.userId}`} className="flex items-center">
            <Avatar className="h-10 w-10 border-2 border-white">
              <div className="bg-accent text-white flex items-center justify-center h-full w-full rounded-full">
                {postCreator ? postCreator.username.charAt(0).toUpperCase() : currentReel.caption.charAt(0).toUpperCase()}
              </div>
            </Avatar>
            <div className="ml-2">
              <p className="text-white text-sm font-semibold flex items-center">
                {postCreator ? postCreator.username : "Creator"}
                {postCreator?.isVerified && (
                  <span className="ml-1 text-blue-300 text-xs">•</span>
                )}
              </p>
              <Button variant="ghost" size="sm" className="h-6 text-xs px-2 py-0 text-white bg-black/30 hover:bg-black/50">
                Follow
              </Button>
            </div>
          </Link>
          
          <div>
            <p className="text-white text-sm line-clamp-2">{currentReel.caption}</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {currentReel.hashtags.map((tag, idx) => (
                <span key={idx} className="text-blue-300 text-xs">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
        
        {/* Comments overlay */}
        {showComments && (
          <div className="absolute inset-0 bg-black/90 backdrop-blur-sm z-10">
            <div className="relative h-full flex flex-col">
              {/* Header */}
              <div className="flex justify-between items-center p-4 border-b border-white/10">
                <h3 className="text-white font-medium">Comments</h3>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10"
                  onClick={() => setShowComments(false)}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Comments list */}
              <div className="flex-1 overflow-y-auto p-4">
                {currentReel.comments.length > 0 ? (
                  <div className="space-y-4">
                    {currentReel.comments.map((comment, index) => {
                      const commentUser = users.find(user => user.id === comment.userId);
                      return (
                        <div key={index} className="flex items-start">
                          <Avatar className="h-8 w-8 mr-2">
                            <div className="bg-accent text-white flex items-center justify-center h-full w-full rounded-full">
                              {commentUser ? commentUser.username.charAt(0).toUpperCase() : comment.username.charAt(0).toUpperCase()}
                            </div>
                          </Avatar>
                          <div>
                            <div className="bg-gray-800 rounded-lg px-3 py-2 text-white">
                              <div className="flex items-center">
                                <p className="text-sm font-medium">
                                  {commentUser ? commentUser.username : comment.username}
                                </p>
                                {commentUser?.isVerified && (
                                  <span className="ml-1 text-blue-400 text-xs">•</span>
                                )}
                              </div>
                              <p className="text-sm">{comment.text} {comment.emoji}</p>
                            </div>
                            <div className="flex items-center mt-1 ml-2 space-x-3">
                              <p className="text-xs text-gray-400">
                                {new Date(comment.timestamp).toLocaleDateString()}
                              </p>
                              <button className="text-xs text-gray-400">Reply</button>
                              <button className="text-xs text-gray-400">Like</button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-10">
                    <p className="text-white/70">No comments yet</p>
                    <p className="text-white/50 text-sm mt-1">Be the first to comment</p>
                  </div>
                )}
              </div>
              
              {/* Comment input */}
              <div className="p-4 border-t border-white/10 bg-gray-900">
                <div className="flex">
                  <Avatar className="h-8 w-8 mr-2">
                    <div className="bg-accent text-white flex items-center justify-center h-full w-full rounded-full">
                      {currentUser ? currentUser.username.charAt(0).toUpperCase() : <User className="h-4 w-4" />}
                    </div>
                  </Avatar>
                  <div className="flex-1 flex items-center space-x-2">
                    <Input
                      placeholder="Add a comment..."
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      className="flex-1 bg-gray-800 border-gray-700 text-white"
                      ref={commentInputRef}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSubmitComment();
                        }
                      }}
                    />
                    <select 
                      className="h-10 px-2 rounded bg-gray-800 border border-gray-700 text-white"
                      value={commentEmoji}
                      onChange={(e) => setCommentEmoji(e.target.value)}
                    >
                      <option value="👍">👍</option>
                      <option value="❤️">❤️</option>
                      <option value="😂">😂</option>
                      <option value="🔥">🔥</option>
                      <option value="👏">👏</option>
                      <option value="🎉">🎉</option>
                      <option value="😍">😍</option>
                      <option value="🙌">🙌</option>
                    </select>
                    <Button 
                      size="icon"
                      onClick={handleSubmitComment}
                      className="bg-blue-500 hover:bg-blue-600"
                    >
                      <Send className="h-4 w-4 text-white" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Carousel thumbnails for other reels */}
      <div className="mt-4">
        <Carousel
          opts={{
            align: "start",
          }}
          className="w-full"
        >
          <CarouselContent>
            {reelPosts.map((reel, index) => (
              <CarouselItem key={reel.id} className="md:basis-1/4 lg:basis-1/5 basis-1/3">
                <div 
                  className={`relative aspect-square rounded-md overflow-hidden ${index === activeReel ? 'ring-2 ring-blue-500' : ''}`} 
                  onClick={() => setActiveReel(index)}
                >
                  <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-black/60" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-2xl">🎬</span>
                  </div>
                  <p className="absolute bottom-1 left-1 right-1 text-white text-xs truncate">
                    {reel.caption}
                  </p>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-1" />
          <CarouselNext className="right-1" />
        </Carousel>
      </div>
    </div>
  );
};

export default Reels;

