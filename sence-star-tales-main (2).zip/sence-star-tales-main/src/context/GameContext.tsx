import React, { createContext, useContext, useState, useEffect } from "react";
import { v4 as uuidv4 } from 'uuid';

// Define types for user, post, and other game-related data
type User = {
  id: string;
  username: string;
  profileImage: string | null;
  bio: string;
  level: number;
  stars: number;
  followers: number;
  followingCount: number;
  isVerified: boolean;
  posts: any[];
  following: string[];
  fame: number; // Added fame property
  dailyBonus: boolean; // Added dailyBonus property
};

type Post = {
  id: string;
  userId: string;
  type: "photo" | "video";
  likes: number;
  comments: any[];
  timestamp: Date;
  caption: string; // Added caption property
  topic: string; // Added topic property
  hashtags: string[]; // Added hashtags property
  likedBy: string[]; // Added likedBy property
  createdAt: Date; // Added createdAt property
  views: number; // Added views property
  imageUrl?: string;
  videoUrl?: string;
};

type Message = {
  id: string;
  conversationId: string;
  text: string;
  timestamp: Date;
  isOwn: boolean;
  read: boolean;
};

type MessageState = {
  [conversationId: string]: Message[];
};

type Conversation = {
  id: string;
  participants: string[];
  lastMessage: string;
  timestamp: Date;
  unread: number;
  name?: string; // Optional, for displaying the other user's name
  online?: boolean; // Optional, for displaying online status
};

type Call = {
  id: string;
  callerId: string;
  receiverId: string;
  startTime: Date;
  endTime?: Date;
  type: 'voice' | 'video';
};

// Define the structure of the game context
type GameContextType = {
  users: User[];
  currentUser: User | null;
  profile: User | null;
  feedPosts: Post[];
  isAuthenticated: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  followUser: (userId: string) => void;
  unfollowUser: (userId: string) => void;
  updateUserProfile: (updates: Partial<User>) => void;
  createPost: (postData: { type: "photo" | "video", topic: string, caption: string, hashtags: string[] }) => void;
  addPost: (postData: { type: "photo" | "video", topic: string, caption: string, hashtags: string[], imageUrl?: string, videoUrl?: string }) => void;
  messages: MessageState;
  setMessages: React.Dispatch<React.SetStateAction<MessageState>>;
  conversations: Conversation[];
  setConversations: React.Dispatch<React.SetStateAction<Conversation[]>>;
  calls: Call[];
  setCalls: React.Dispatch<React.SetStateAction<Call[]>>;
  getConversations: () => Conversation[];
  getMessages: (conversationId: string) => Message[];
  sendMessage: (conversationId: string, text: string) => void;
  startConversation: (otherUserId: string) => Conversation;
  initiateCall: (receiverId: string, type: 'voice' | 'video') => Call;
  endCall: (callId: string) => void;
  availableTopics: string[]; // Added availableTopics property
  availableHashtags: string[]; // Added availableHashtags property
  likePost: (postId: string) => void; // Added likePost method
  addComment: (postId: string, text: string, emoji: string) => void; // Added addComment method
  collectDailyBonus: () => void; // Added collectDailyBonus method
  calculateLevel: (fame: number) => number; // Added calculateLevel method
  addStars: (amount: number) => void; // Added addStars method
  register: (username: string, password: string) => boolean; // Added register method
};

// Create the game context
const GameContext = createContext<GameContextType | undefined>(undefined);

// Custom hook to use the game context
export const useGameContext = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error("useGameContext must be used within a GameProvider");
  }
  return context;
};

// Helper function to load data from local storage
const loadFromStorage = <T,>(key: string, defaultValue: T): T => {
  try {
    const serializedValue = localStorage.getItem(key);
    if (serializedValue === null) {
      return defaultValue;
    }
    return JSON.parse(serializedValue) as T;
  } catch (error) {
    console.error("Error loading from local storage:", error);
    return defaultValue;
  }
};

// Helper function to save data to local storage
const saveToStorage = <T,>(key: string, value: T): void => {
  try {
    const serializedValue = JSON.stringify(value);
    localStorage.setItem(key, serializedValue);
  } catch (error) {
    console.error("Error saving to local storage:", error);
  }
};

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state variables
  const [users, setUsers] = useState<User[]>(() =>
    loadFromStorage("senceUsers", [
      {
        id: "1",
        username: "john_doe",
        profileImage: "https://i.pravatar.cc/150?img=1",
        bio: "Travel enthusiast and photographer",
        level: 5,
        stars: 120,
        followers: 250,
        followingCount: 100,
        isVerified: true,
        posts: [{ id: "1", type: "photo" }, { id: "2", type: "video" }],
        following: ["2", "3"],
        fame: 450,
        dailyBonus: true
      },
      {
        id: "2",
        username: "jane_smith",
        profileImage: "https://i.pravatar.cc/150?img=2",
        bio: "Food lover and cooking enthusiast",
        level: 3,
        stars: 80,
        followers: 180,
        followingCount: 80,
        isVerified: false,
        posts: [{ id: "3", type: "photo" }],
        following: ["1"],
        fame: 280,
        dailyBonus: true
      },
      {
        id: "3",
        username: "alice_wonderland",
        profileImage: "https://i.pravatar.cc/150?img=3",
        bio: "Nature lover and hiking enthusiast",
        level: 7,
        stars: 180,
        followers: 320,
        followingCount: 150,
        isVerified: true,
        posts: [{ id: "4", type: "photo" }, { id: "5", type: "video" }],
        following: ["1"],
        fame: 650,
        dailyBonus: false
      },
      {
        id: "4",
        username: "bob_the_builder",
        profileImage: "https://i.pravatar.cc/150?img=4",
        bio: "DIY enthusiast and home improvement expert",
        level: 4,
        stars: 100,
        followers: 200,
        followingCount: 90,
        isVerified: false,
        posts: [{ id: "6", type: "photo" }],
        following: [],
        fame: 320,
        dailyBonus: true
      },
      {
        id: "5",
        username: "eve_online",
        profileImage: "https://i.pravatar.cc/150?img=5",
        bio: "Gamer and esports enthusiast",
        level: 6,
        stars: 150,
        followers: 280,
        followingCount: 120,
        isVerified: true,
        posts: [{ id: "7", type: "photo" }, { id: "8", type: "video" }],
        following: [],
        fame: 520,
        dailyBonus: false
      },
    ])
  );
  
  const [currentUser, setCurrentUser] = useState<User | null>(() =>
    loadFromStorage("senceCurrentUser", null)
  );
  
  const [profile, setProfile] = useState<User | null>(() =>
    loadFromStorage("senceProfile", null)
  );
  
  const [feedPosts, setFeedPosts] = useState<Post[]>(() =>
    loadFromStorage("senceFeedPosts", [
      {
        id: "1",
        userId: "1",
        type: "photo",
        likes: 50,
        comments: [{ id: "1", userId: "2", text: "Nice shot!", username: "jane_smith", timestamp: new Date(), emoji: "👍" }],
        timestamp: new Date(),
        caption: "Enjoying the beautiful sunset today!",
        topic: "Nature",
        hashtags: ["#sunset", "#nature", "#photography"],
        likedBy: ["2", "3"],
        createdAt: new Date(),
        views: 120,
        imageUrl: "https://images.unsplash.com/photo-1523712999610-f77fbcfc3843"
      },
      {
        id: "2",
        userId: "2",
        type: "video",
        likes: 80,
        comments: [{ id: "2", userId: "1", text: "Cool video!", username: "john_doe", timestamp: new Date(), emoji: "🔥" }],
        timestamp: new Date(),
        caption: "My new cooking recipe, try it out!",
        topic: "Food",
        hashtags: ["#cooking", "#recipe", "#foodie"],
        likedBy: ["1", "4"],
        createdAt: new Date(),
        views: 200,
        videoUrl: "https://example.com/video.mp4"
      },
      {
        id: "3",
        userId: "1",
        type: "photo",
        likes: 120,
        comments: [
          { id: "3", userId: "3", text: "Amazing!", username: "alice_wonderland", timestamp: new Date(), emoji: "😍" },
          { id: "4", userId: "4", text: "Great work!", username: "bob_the_builder", timestamp: new Date(), emoji: "👏" }
        ],
        timestamp: new Date(),
        caption: "My latest photography project",
        topic: "Art",
        hashtags: ["#photography", "#art", "#project"],
        likedBy: ["2", "3", "4", "5"],
        createdAt: new Date(),
        views: 350,
        imageUrl: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158"
      },
      {
        id: "4",
        userId: "3",
        type: "photo",
        likes: 65,
        comments: [{ id: "5", userId: "1", text: "Beautiful!", username: "john_doe", timestamp: new Date(), emoji: "❤️" }],
        timestamp: new Date(),
        caption: "Hiking in the mountains today",
        topic: "Travel",
        hashtags: ["#hiking", "#mountains", "#adventure"],
        likedBy: ["1", "2"],
        createdAt: new Date(),
        views: 180,
        imageUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb"
      },
      {
        id: "5",
        userId: "5",
        type: "video",
        likes: 95,
        comments: [{ id: "6", userId: "2", text: "Awesome!", username: "jane_smith", timestamp: new Date(), emoji: "🎮" }],
        timestamp: new Date(),
        caption: "New gaming setup tour",
        topic: "Gaming",
        hashtags: ["#gaming", "#setup", "#tech"],
        likedBy: ["1", "2", "4"],
        createdAt: new Date(),
        views: 280,
        videoUrl: "https://example.com/video2.mp4"
      },
    ])
  );
  
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return !!loadFromStorage("senceCurrentUser", null);
  });

  // Ensure consistent global state (not inside any function)
  const [messages, setMessages] = useState<MessageState>(() =>
    loadFromStorage("senceMessages", {})
  );

  const [conversations, setConversations] = useState<Conversation[]>(() =>
    loadFromStorage("senceConversations", [])
  );

  const [calls, setCalls] = useState<Call[]>(() =>
    loadFromStorage("senceCalls", [])
  );
  
  // Define available topics and hashtags
  const availableTopics = ["Food", "Travel", "Fashion", "Tech", "Gaming", "Art", "Music", "Sports", "Nature", "Lifestyle"];
  const availableHashtags = ["#trending", "#viral", "#love", "#fashion", "#art", "#photography", "#travel", "#food", "#fitness", "#beauty", "#music", "#lifestyle", "#nature", "#tech"];

  // Calculate level based on fame
  const calculateLevel = (fame: number) => {
    return Math.floor(fame / 100) + 1;
  };

  // Define login function
  const login = (username: string, password: string): boolean => {
    const user = users.find((user) => user.username === username);
    if (user) {
      setCurrentUser(user);
      setProfile(user);
      setIsAuthenticated(true);
      saveToStorage("senceCurrentUser", user);
      saveToStorage("senceProfile", user);
      return true;
    }
    return false;
  };
  
  // Define register function
  const register = (username: string, password: string): boolean => {
    const existingUser = users.find(user => user.username === username);
    if (existingUser) {
      return false;
    }
    
    const newUser: User = {
      id: uuidv4(),
      username,
      profileImage: null,
      bio: "",
      level: 1,
      stars: 50,
      followers: 0,
      followingCount: 0,
      isVerified: false,
      posts: [],
      following: [],
      fame: 0,
      dailyBonus: true
    };
    
    setUsers(prev => {
      const updated = [...prev, newUser];
      saveToStorage("senceUsers", updated);
      return updated;
    });
    
    setCurrentUser(newUser);
    setProfile(newUser);
    setIsAuthenticated(true);
    saveToStorage("senceCurrentUser", newUser);
    saveToStorage("senceProfile", newUser);
    return true;
  };

  // Define logout function
  const logout = () => {
    setCurrentUser(null);
    setProfile(null);
    setIsAuthenticated(false);
    localStorage.removeItem("senceCurrentUser");
    localStorage.removeItem("senceProfile");
  };

  // Define followUser function
  const followUser = (userId: string) => {
    if (!currentUser) return;

    setUsers((prevUsers) => {
      const updatedUsers = prevUsers.map((user) => {
        if (user.id === currentUser.id) {
          return { ...user, following: [...user.following, userId] };
        }
        return user;
      });
      saveToStorage("senceUsers", updatedUsers);
      return updatedUsers;
    });

    setCurrentUser((prevCurrentUser) => {
      if (prevCurrentUser) {
        const updatedUser = {
          ...prevCurrentUser,
          following: [...prevCurrentUser.following, userId],
        };
        saveToStorage("senceCurrentUser", updatedUser);
        return updatedUser;
      }
      return prevCurrentUser;
    });
  };

  // Define unfollowUser function
  const unfollowUser = (userId: string) => {
    if (!currentUser) return;

    setUsers((prevUsers) => {
      const updatedUsers = prevUsers.map((user) => {
        if (user.id === currentUser.id) {
          return {
            ...user,
            following: user.following.filter((id) => id !== userId),
          };
        }
        return user;
      });
      saveToStorage("senceUsers", updatedUsers);
      return updatedUsers;
    });

    setCurrentUser((prevCurrentUser) => {
      if (prevCurrentUser) {
        const updatedUser = {
          ...prevCurrentUser,
          following: prevCurrentUser.following.filter((id) => id !== userId),
        };
        saveToStorage("senceCurrentUser", updatedUser);
        return updatedUser;
      }
      return prevCurrentUser;
    });
  };

  const updateUserProfile = (updates: Partial<User>) => {
    if (!currentUser) return;

    setUsers((prevUsers) => {
      const updatedUsers = prevUsers.map((user) => {
        if (user.id === currentUser.id) {
          return { ...user, ...updates };
        }
        return user;
      });
      saveToStorage("senceUsers", updatedUsers);
      return updatedUsers;
    });

    setCurrentUser((prevCurrentUser) => {
      if (prevCurrentUser) {
        const updatedUser = { ...prevCurrentUser, ...updates };
        saveToStorage("senceCurrentUser", updatedUser);
        return updatedUser;
      }
      return prevCurrentUser;
    });

    setProfile((prevProfile) => {
      if (prevProfile && prevProfile.id === currentUser.id) {
        return { ...prevProfile, ...updates };
      }
      return prevProfile;
    });
  };

  // Function to create a new post
  const createPost = (postData: { type: "photo" | "video", topic: string, caption: string, hashtags: string[] }) => {
    if (!currentUser) return;

    const newPost: Post = {
      id: uuidv4(),
      userId: currentUser.id,
      type: postData.type,
      likes: 0,
      comments: [],
      timestamp: new Date(),
      caption: postData.caption,
      topic: postData.topic,
      hashtags: postData.hashtags,
      likedBy: [],
      createdAt: new Date(),
      views: 0
    };

    setFeedPosts((prevPosts) => {
      const updatedPosts = [newPost, ...prevPosts];
      saveToStorage("senceFeedPosts", updatedPosts);
      return updatedPosts;
    });

    setUsers((prevUsers) => {
      const updatedUsers = prevUsers.map((user) => {
        if (user.id === currentUser.id) {
          return { ...user, posts: [...user.posts, newPost] };
        }
        return user;
      });
      saveToStorage("senceUsers", updatedUsers);
      return updatedUsers;
    });
    
    // Add fame for creating a post
    addStars(5);
    updateUserProfile({ fame: (currentUser.fame || 0) + 10 });
  };
  
  // Function to like a post
  const likePost = (postId: string) => {
    if (!currentUser) return;
    
    setFeedPosts(prevPosts => {
      const updatedPosts = prevPosts.map(post => {
        if (post.id === postId) {
          const alreadyLiked = post.likedBy?.includes(currentUser.id);
          
          if (alreadyLiked) {
            return {
              ...post,
              likes: post.likes - 1,
              likedBy: post.likedBy.filter(id => id !== currentUser.id)
            };
          } else {
            return {
              ...post,
              likes: post.likes + 1,
              likedBy: [...(post.likedBy || []), currentUser.id]
            };
          }
        }
        return post;
      });
      
      saveToStorage("senceFeedPosts", updatedPosts);
      return updatedPosts;
    });
  };
  
  // Function to add a comment to a post
  const addComment = (postId: string, text: string, emoji: string) => {
    if (!currentUser) return;
    
    const newComment = {
      id: uuidv4(),
      userId: currentUser.id,
      text,
      emoji,
      username: currentUser.username,
      timestamp: new Date()
    };
    
    setFeedPosts(prevPosts => {
      const updatedPosts = prevPosts.map(post => {
        if (post.id === postId) {
          return {
            ...post,
            comments: [...post.comments, newComment]
          };
        }
        return post;
      });
      
      saveToStorage("senceFeedPosts", updatedPosts);
      return updatedPosts;
    });
    
    // Add fame/stars for the post creator
    const post = feedPosts.find(p => p.id === postId);
    if (post && post.userId !== currentUser.id) {
      const postCreator = users.find(u => u.id === post.userId);
      if (postCreator) {
        setUsers(prevUsers => {
          const updated = prevUsers.map(user => {
            if (user.id === post.userId) {
              return {
                ...user,
                fame: (user.fame || 0) + 2,
                stars: user.stars + 2
              };
            }
            return user;
          });
          saveToStorage("senceUsers", updated);
          return updated;
        });
      }
    }
  };
  
  // Function to collect daily bonus
  const collectDailyBonus = () => {
    if (!currentUser || !currentUser.dailyBonus) return;
    
    addStars(50);
    
    updateUserProfile({
      dailyBonus: false
    });
    
    // Reset daily bonus after 24 hours
    setTimeout(() => {
      updateUserProfile({
        dailyBonus: true
      });
    }, 1000 * 60 * 5); // 5 minutes for testing (would be 24 hours in production)
  };
  
  // Function to add stars to the current user
  const addStars = (amount: number) => {
    if (!currentUser) return;
    
    updateUserProfile({
      stars: currentUser.stars + amount
    });
  };

  // Function to add a new post
  const addPost = (postData: { type: "photo" | "video", topic: string, caption: string, hashtags: string[], imageUrl?: string, videoUrl?: string }) => {
    if (!currentUser) return;

    const newPost: Post = {
      id: uuidv4(),
      userId: currentUser.id,
      type: postData.type,
      likes: 0,
      comments: [],
      timestamp: new Date(),
      caption: postData.caption,
      topic: postData.topic,
      hashtags: postData.hashtags,
      likedBy: [],
      createdAt: new Date(),
      views: 0,
      imageUrl: postData.imageUrl,
      videoUrl: postData.videoUrl
    };

    setFeedPosts((prevPosts) => {
      const updatedPosts = [newPost, ...prevPosts];
      saveToStorage("senceFeedPosts", updatedPosts);
      return updatedPosts;
    });

    setUsers((prevUsers) => {
      const updatedUsers = prevUsers.map((user) => {
        if (user.id === currentUser.id) {
          return { ...user, posts: [...user.posts, newPost] };
        }
        return user;
      });
      saveToStorage("senceUsers", updatedUsers);
      return updatedUsers;
    });
    
    // Add fame for creating a post
    addStars(5);
    updateUserProfile({ fame: (currentUser.fame || 0) + 10 });
  };

  // All functions must reference correct messages/conversations/calls state.
  // For example:
  // To get conversations, use the current state:
  const getConversations = () => conversations;

  // To get messages for a conversation:
  const getMessages = (conversationId: string) => messages[conversationId] || [];

  // To send a new message:
  const sendMessage = (conversationId: string, text: string) => {
    if (!currentUser) return;

    const newMessage = {
      id: Date.now().toString(),
      conversationId,
      text,
      timestamp: new Date(),
      isOwn: true,
      read: false,
    };
    setMessages(prev => {
      const convMsgs = prev[conversationId] || [];
      const updated = {
        ...prev,
        [conversationId]: [...convMsgs, newMessage]
      };
      saveToStorage("senceMessages", updated);
      return updated;
    });
    // Also update the last message and timestamp in conversations
    setConversations(prev => {
      const updated = prev.map(conv =>
        conv.id === conversationId
          ? { ...conv, lastMessage: text, timestamp: new Date() }
          : conv
      );
      saveToStorage("senceConversations", updated);
      return updated;
    });
  };

  // To initiate a new conversation:
  const startConversation = (otherUserId: string) => {
    if (!currentUser) return null;

    // If a conversation between these users exists, return it
    let conversation = conversations.find(conv =>
      conv.participants.includes(otherUserId)
    );
    if (!conversation) {
      conversation = {
        id: Date.now().toString(),
        participants: [currentUser?.id, otherUserId].filter(Boolean) as string[],
        lastMessage: "",
        timestamp: new Date(),
        unread: 0,
      };
      setConversations(prev => {
        const updated = [...prev, conversation!];
        saveToStorage("senceConversations", updated);
        return updated;
      });
    }
    return conversation;
  };

  const initiateCall = (receiverId: string, type: 'voice' | 'video'): Call => {
    if (!currentUser) {
      throw new Error("No current user.");
    }

    const newCall: Call = {
      id: uuidv4(),
      callerId: currentUser.id,
      receiverId: receiverId,
      startTime: new Date(),
      type: type,
    };

    setCalls(prevCalls => {
      const updatedCalls = [...prevCalls, newCall];
      saveToStorage("senceCalls", updatedCalls);
      return updatedCalls;
    });

    return newCall;
  };

  const endCall = (callId: string): void => {
    setCalls(prevCalls => {
      const updatedCalls = prevCalls.map(call => {
        if (call.id === callId) {
          return { ...call, endTime: new Date() };
        }
        return call;
      }).filter(call => call.id !== callId); // Remove the call after ending
      saveToStorage("senceCalls", updatedCalls);
      return updatedCalls;
    });
  };
  
  // Daily reset of bonuses
  useEffect(() => {
    const resetDailyBonuses = () => {
      setUsers(prevUsers => {
        const updated = prevUsers.map(user => ({
          ...user,
          dailyBonus: true
        }));
        saveToStorage("senceUsers", updated);
        return updated;
      });
      
      if (currentUser) {
        setCurrentUser(prev => {
          if (prev) {
            const updated = {
              ...prev,
              dailyBonus: true
            };
            saveToStorage("senceCurrentUser", updated);
            return updated;
          }
          return prev;
        });
      }
    };
    
    // Reset every day at midnight
    const now = new Date();
    const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const timeToMidnight = tomorrow.getTime() - now.getTime();
    
    const timer = setTimeout(resetDailyBonuses, timeToMidnight);
    return () => clearTimeout(timer);
  }, [currentUser]);
  
  // The context value must expose these updated states and methods!
  const contextValue: GameContextType = {
    users,
    currentUser,
    profile,
    feedPosts,
    isAuthenticated,
    login,
    logout,
    followUser,
    unfollowUser,
    updateUserProfile,
    createPost,
    addPost,
    messages,
    setMessages,
    conversations,
    setConversations,
    calls,
    setCalls,
    getConversations,
    getMessages,
    sendMessage,
    startConversation,
    initiateCall,
    endCall,
    availableTopics,
    availableHashtags,
    likePost,
    addComment,
    collectDailyBonus,
    calculateLevel,
    addStars,
    register
  };

  return (
    <GameContext.Provider value={contextValue}>
      {children}
    </GameContext.Provider>
  );
};

export default GameProvider;
